<?php


if($_SESSION['teamFilter'])
	$filterTag = "AND team_id='".$_SESSION['teamFilter']."'";
if($_SESSION['locationFilter'])
	$filterTag .= " AND location_id='".$_SESSION['locationFilter']."'";

mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");
$query = "SELECT name, coreID , primary_team, team_id, location, location_id FROM employee_all
			WHERE TRUE $filterTag
			ORDER BY primary_team";
$result = mysql_db_query("autoapps", $query);

writeTableHeader('listteams', array('name','coreID', 'team','location'));
while($r = mysql_fetch_array($result)){
echo "<tr>";
	writeRefTd($r['name'], 'index.php?site=changeSkill&amp;listOther='.$r['coreID']);
	writeRefTd($r['coreID'], 'index.php?site=changeSkill&amp;listOther='.$r['coreID']);
	writeRefTd($r['primary_team'], 'index.php?site=changeSkill&amp;listOtherTeam='.$r['team_id']);
	writeRefTd($r['location'], 'index.php?site=changeSkill&amp;listOtherLoc='.$r['location_id']);
echo "</tr>";
}
writeTableEnd();

?>