<table  align=right class="tab" border=1  style="height:275px;" >
	<tr>
		<td style="background-color: <?php echo $table_title_color;?>;">level of <br>Expertise
		</td>
		<td style="background-color: <?php echo $table_title_color;?>;">level of <br>interest
		</td>
	</tr>
		<?php

		$query = "select count(coreID) AS count from employee";
		$result = mysql_db_query("autoapps", $query);
		$r = mysql_fetch_array($result);

		$count = $r['count'];

		$query = "select SUM(lvlOfExpert) AS sumExpert, SUM(lvlOfIntr) AS sumIntr
					from employee_has_skill where skill_idskill='$idskill'";
				$result = mysql_db_query("autoapps", $query);
				$r = mysql_fetch_array($result);

		$avgExpert = round($r['sumExpert']/$count,2);
		$avgIntr = round($r['sumIntr']/$count,2);

		$query = "SELECT
					SUM(lvlOfExpert) AS sumExpert
					, AVG(lvlOfExpert) AS avgExpert
					, SUM(lvlOfIntr) AS sumIntr
					, AVG(lvlOfIntr) AS avgIntr
					FROM employee_has_skill WHERE  skill_idskill='$idskill'";
		$result = mysql_db_query("autoapps", $query);
		$r = mysql_fetch_array($result);
		$sum = "";

		if($result){
			$sum.="<td>sum: ".$r['sumExpert']."</td>";
			$sum.="<td>sum: ".$r['sumIntr']."</td>";
			echo $sum;
		}
		else
		{
			echo "failure";
		}


		mysql_free_result($result);
		?>
	<tr>
		<td valign=bottom height=180>
			<table class="no_lines" border=0>
				<tr higth=300>
					<td align=center valign=bottom><img src='img/bar.gif' width='8' height=<? echo ($avgExpert * 25); ?>>
					</td>
					<td align=center valign=bottom><img src='img/bar.gif' width='8' height=<? echo ($lvlOfExpert * 25); ?>>
					</td>
				</tr>
				<tr>
					<td align=center valign=bottom><? echo ($avgExpert); ?>
					</td>
					<td align=center><? echo $lvlOfExpert; ?>
					</td>
				</tr>
				<tr>
					<td align=center>avg
					</td>
					<td align=center>you
					</td>
				</tr>
			</table>
		</td>
		<td valign=bottom height=180>
			<table class="no_lines" border=0>
				<tr higth=300>
					<td align=center valign=bottom><img src='img/bar.gif' width='8' height=<? echo ($avgIntr * 25); ?>>
					</td>
					<td align=center valign=bottom><img src='img/bar.gif' width='8' height=<? echo ($lvlOfIntr * 25); ?>>
					</td>
				</tr>
				<tr>
					<td align=center valign=bottom><? echo ($avgIntr); ?>
					</td>
					<td align=center><? echo $lvlOfIntr; ?>
					</td>
				</tr>
				<tr>
					<td align=center>avg
					</td>
					<td align=center>you
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>