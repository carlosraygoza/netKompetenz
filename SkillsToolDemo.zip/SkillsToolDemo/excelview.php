<br>
<h4>excel view</h4>

<?php


mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");


$team = array();

$skills = array(array());

$skill_names = array();
$skill_ids = array();

$teams = array();
$teams_col_span = array();

$empl_row = array();

$skillpointer = 0;

$empl = array();

$bgcolors = array('rgb(233, 237, 206)','rgb(208, 215, 142)','rgb(195, 204, 81)','rgb(172, 181, 0)','rgb(153, 136, 117)');

if($_SESSION['teamFilter'])
	$filterTag = "AND team_id='".$_SESSION['teamFilter']."'";
if($_SESSION['locationFilter'])
	$filterTag .= " AND location_id='".$_SESSION['locationFilter']."'";


$query ="SELECT coreID,name,primary_team AS team, team_id, location, location_id
FROM employee_all
WHERE TRUE $filterTag
GROUP BY name
ORDER BY team";


$sql = mysql_db_query("autoapps", $query);

$numEmpl=0;
while($data = mysql_fetch_array($sql)){

	//if($_SESSION['teamFilter'] == '' OR $_SESSION['teamFilter'] == $data['team_id']){
		$empl_row[$data['name']]=$numEmpl;
		$empl[$numEmpl] = $data['name'];
		$team[$numEmpl] = $data['team'];
		$numEmpl++;
	//}
}


$query ="SELECT coreID,name, description ,primary_team AS team,lvlOfExpert,skill_idskill AS idskill
FROM employee_all
INNER JOIN employee_has_skill
ON employee_has_skill.employee_coreID=employee_all.coreID
INNER JOIN skill
ON skill.idskill=employee_has_skill.skill_idskill
ORDER BY idskill";

$sql = mysql_db_query("autoapps", $query);

while($data = mysql_fetch_array($sql)){

	$skills[$data['idskill']][$empl_row[$data['name']]] = $data['lvlOfExpert'];
	$skill_names[$data['idskill']] = $data['description'];
	$skill_ids[$data['idskill']] = $data['idskill'];

}



echo "<br><b>$title </b><a href='index.php?export=excelview' align='right'>export </a>";
if($_GET['export']=="excelview"){
	$export = 1;
	echo "<a href='excelview.csv'> | right click here to download .csv file</a>";
}

if($_SESSION['teamFilter'])
	$table = "<table class='sortable' id='excelview'  align=left border=1>";
else{
	$table = "<table class='tab' id='excelview'  align=left border=1>";


	$table .="<tr class='unsortable'>";

	$table .= "<td >Team:</td>";

	if($export){
		$exportTable = "Team, ";
	}

	$col_span=1;

	if($export){
				$exportTable .= $team[0].",";
	}

	$m = 1;
	while($team[$m]){

		if($export){
			$exportTable .= $team[$m].",";
		}

		if($team[$m]==$team[$m-1]){
		 $col_span++;
		 }
		else {
			$table .= "<td style='width: 20px;background-color:rgb(255,221,0)' COLSPAN=".$col_span.">".$team[$m-1]."</td>";
			$col_span=1;
		}
	$m++;
	}
	$table  .="<td style='background-color:rgb(255,221,0) ' COLSPAN=".$col_span.">".$team[$m-1]."</td>";

	$table .="</tr>";
}

$table .="<tr >";

$table .= "<td >skill</td>";

if($export){
	$exportTable .= "\n skill,";
}

		foreach($empl as $tmp_name){

				$table .= "<td style='width: 20px; layout-flow : vertical-ideographic;background-color:$table_title_color'>";
				$table .= $tmp_name;
				$table .= "</td>";
				if($export){
					$exportTable .= $tmp_name.",";
				}

		}


$table .="</tr>";

if($export){
	$exportTable .= "\n";
}



foreach($skills as $key=>$tmp_skill){

	$tmp_table .= "<tr>";

	$has_entry = 0;

	$tmp_table .= "<td><a href='index.php?site=skillentry&amp;id=$skill_ids[$key]'>$skill_names[$key]</a></td>";

	if($export){
		$exportTable .=$skill_names[$key].",";
	}

	for($m=0; $m<count($empl); $m++){
		if($bgcolors[$tmp_skill[$m]]){
			$bgcolor = $bgcolors[$tmp_skill[$m]];
			$has_entry = 1;
		}
		else
			$bgcolor = $bgcolors[0];

		$tmp_table .= "<td style='background-color: ".$bgcolor ."'>";
		$tmp_table .= $tmp_skill[$m];
		$tmp_table .= "</td>";

		if($export){
			$exportTable .= "$tmp_skill[$m] ,";
		}

	}

	$tmp_table .="</tr>
	";

	if($export){
				$exportTable .= "\n";
	}

	if($has_entry)
		$table .= $tmp_table;
	$tmp_table = '';
}



$table .= "</table>";

echo $table;


if($export){

	unlink('excelview.csv');

	$f = fopen ('excelview.csv','w');

		// Put all values from $out to export.csv.
	fputs($f, $exportTable);
	fclose($f);
}



?>