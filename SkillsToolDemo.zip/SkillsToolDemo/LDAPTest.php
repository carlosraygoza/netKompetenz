<?php 

$conn = ldap_connect("HI2C102A.cw01.contiwan.com") or die("Could not connect");

if(isset($_POST['uid']) && $_POST['uid'] != "")
{

	$auth = @ldap_bind($conn,$_POST['uid']."@cw01.contiwan.com",$_POST['pass']);

	if ($auth) 
	{
		echo "Credenciales correctas";
	}
	else
	{
		echo "Credenciales incorrectas";
	}
}
elseif (isset($_POST['search'])) 
{
	$uid = $_POST['search'];
	$filter = "(|(uid=$uid))";
	$justthese = array("ou", "sn", "givenname", "mail");
	
	$sr=ldap_search($conn, "cw01", $filter, $justthese);

	$info = ldap_get_entries($conn, $sr);

	echo $info['count'];
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post">
	<table>
		<tr>
			<td><label>UID:</label></td>
			<td><input type="text" name="uid"></td>
		</tr>
		<tr>
			<td><label>Pass:</label></td>
			<td><input type="password" name="pass"></td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" value="submit"></td>
		</tr>
	</table>
	</form>
	<form method="post">
		<input type="text" name="search">
		<input type="submit" value="submit">
	</form>
</body>
</html>