<?php

if($_SESSION['teamFilter'])
	$teamFilterTag = "AND primary_team_id='".$_SESSION['teamFilter']."'";
else
	$teamFilterTag = '';

if($_SESSION['locationFilter'])
	$locationFilterTag = "AND location_id='".$_SESSION['locationFilter']."'";
else
	$locationFilterTag = '';

$query =   "SELECT
emp.name AS name,
emp.location_id AS location_id,
emp.coreID AS coreID,
emp.primary_team_id AS team,
employee_has_skill.lvlOfExpert AS expert,
employee_has_skill.lvlOfIntr AS intr
FROM employee AS emp
INNER JOIN employee_has_skill
ON employee_has_skill.employee_coreID=emp.coreID
WHERE employee_has_skill.skill_idskill=$idskill $teamFilterTag $locationFilterTag
ORDER BY expert DESC";

$result = mysql_db_query("autoapps", $query);


$headers = array('Name','UID','Team','Location','Expertise','Interest');

writeTableTitleWithExport("People with this skill:", 'listOfSkillOwners', $query);
writeTableHeader('listOfSkillOwners', $headers);


while($r = mysql_fetch_array($result)){
echo "<tr>";
writeRefTd($r['name'], 'index.php?site=changeSkill&amp;listOther='.$r['coreID']);
writeRefTd($r['coreID'], 'index.php?site=changeSkill&amp;listOther='.$r['coreID']);
writeRefTd($r['team'], 'index.php?site=changeSkill&amp;listOtherTeam='.$r['team_id']);
writeRefTd($r['location_id'], 'index.php?site=changeSkill&amp;listOtherLoc='.$r['location_id']);
writeBarTd('img/bar.gif',$r['expert'], 4);
writeBarTd('img/bar.gif',$r['intr'], 4);
echo "
</tr>";
}

writeTableEnd();


$query =   "SELECT
			MAX(SumExpert) AS maxSumExpert
			, MAX(SumIntr) AS maxSumIntr
			FROM
			(
				SELECT primary_team
				, team_id
				, skill_idskill AS skillID
				, location
				, SUM(lvlOfExpert) AS SumExpert
				, SUM(lvlOfIntr) AS SumIntr
				FROM employee_has_skill
				INNER JOIN employee_all
				ON employee_all.coreID=employee_has_skill.employee_coreID
				Where employee_has_skill.skill_idskill=$idskill $teamFilterTag
				GROUP BY primary_team
			) AS temp";

$result = mysql_db_query("autoapps", $query);
$r = mysql_fetch_array($result);

$maxSumExpert=$r['maxSumExpert']!=0?$r['maxSumExpert']:1;
$maxSumIntr=$r['maxSumIntr']!=0?$r['maxSumIntr']:1;
$maxSumWork=$r['maxSumWork']!=0?$r['maxSumWork']:1;



$query =   "SELECT primary_team_id AS team, 
			location_id, 
			SUM(lvlOfExpert) AS sumExpert, SUM(lvlOfIntr) AS sumIntr, numOfMem
			FROM employee
			INNER JOIN
			(SELECT primary_team_id AS team ,COUNT(employee.primary_team_id) AS numOfMem
			FROM employee
			GROUP BY employee.primary_team_id) AS temp
			ON employee.primary_team_id=team
			INNER JOIN employee_has_skill
			ON employee_has_skill.employee_coreID=employee.coreID
			WHERE employee_has_skill.skill_idskill=$idskill $teamFilterTag
			GROUP BY primary_team_id
			ORDER BY sumExpert DESC";

$result = mysql_db_query("autoapps", $query);

$headers = array('Team','Expertise Avg','Expertise Sum','Interest Avg','Interest Sum',);

writeTableTitleWithExport("Grouped by Team:", 'skillsByTeam', $query);
writeTableHeader('skillsByTeam', $headers);


while($r = mysql_fetch_array($result)){
echo "<tr>";
writeRefTd($r['team'], 'index.php?site=changeSkill&amp;listOtherTeam='.$r['team_id']);
writeBarTd('img/bar.gif',($r['sumExpert'] /$r['numOfMem']), 4);
writeBarTd('img/bar.gif', $r['sumExpert'],20); //Hardcoded in 50 avoid having huge bars. TODO. Needs to be fixed properly setting the highest element a fixed value and the rest of the elements a percentage of it.
writeBarTd('img/bar.gif',($r['sumIntr'] /$r['numOfMem']), 4);
writeBarTd('img/bar.gif', $r['sumIntr'],20);//TODO. Same as above
echo "
</tr>";
}

writeTableEnd();



$query =   "SELECT
			MAX(SumExpert) AS maxSumExpert
			, MAX(SumIntr) AS maxSumIntr

			FROM
			(
				SELECT primary_team
				, skill_idskill AS skillID
				, location
				, location_id
				, SUM(lvlOfExpert) AS SumExpert
				, SUM(lvlOfIntr) AS SumIntr
				FROM employee_has_skill
				INNER JOIN employee_all
				ON employee_all.coreID=employee_has_skill.employee_coreID
				Where employee_has_skill.skill_idskill=$idskill $locationFilterTag
				GROUP BY location
			) AS temp";

$result = mysql_db_query("autoapps", $query);
$r = mysql_fetch_array($result);

$maxSumExpert=$r['maxSumExpert']!=0?$r['maxSumExpert']:1;
$maxSumIntr=$r['maxSumIntr']!=0?$r['maxSumIntr']:1;
$maxSumWork=$r['maxSumWork']!=0?$r['maxSumWork']:1;







$query =   "SELECT location_id, SUM(lvlOfExpert) AS sumExpert, SUM(lvlOfIntr) AS sumIntr, numOfMem
			FROM employee
			INNER JOIN
			(SELECT employee.location_id AS location_temp ,COUNT(employee.location_id) AS numOfMem
			FROM employee
			GROUP BY employee.location_id ) AS temp
			ON employee.location_id=location_temp
			INNER JOIN employee_has_skill
			ON employee_has_skill.employee_coreID=employee.coreID
			WHERE employee_has_skill.skill_idskill=$idskill $locationFilterTag
			GROUP BY location_id
			ORDER BY sumExpert DESC";

$result = mysql_db_query("autoapps", $query);

$headers = array('Location','Expertise Avg','Expertise Sum','Interest Avg','Interest Sum');

writeTableTitleWithExport("Grouped by Location:", 'skillsByLocation', $query);
writeTableHeader('skillsByLocation', $headers);


while($r = mysql_fetch_array($result)){
echo "<tr>";
writeRefTd($r['location_id'], 'index.php?site=changeSkill&amp;listOtherLoc='.$r['location_id']);
writeBarTd('img/bar.gif',($r['sumExpert'] /$r['numOfMem']), 4);
writeBarTd('img/bar.gif', $r['sumExpert'],20); // TODO: Same as above
writeBarTd('img/bar.gif',($r['sumIntr'] /$r['numOfMem']), 4);
writeBarTd('img/bar.gif', $r['sumIntr'],20); // TODO: Same as above
echo "
</tr>";
}

writeTableEnd();



mysql_free_result($result);

?>