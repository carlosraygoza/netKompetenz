<?php
	$xmlphp = 'xml.php';
	//echo $_POST['182_100'];
	//$_SESSION['post'] = $_POST;
	//echo $_SESSION['post'];
	if(!$_SESSION['openNodes']){
		$_SESSION['openNodes'] = array();
	}

	if($_GET['site']=='groupeditor'){
		$menutag="&site=groupeditor&addGroupSkill=1";
	}
	else if($_GET['site']=='treeeditor'){
		$menutag="&site=treeeditor";
	}
	else if($_GET['site']=='changeSkill'){
			$menutag="&site=changeSkill";
	}
	else
		$menutag="&site=skillentry";

	foreach($_POST AS $key=>$val){
		$_SESSION['openNodes'][$key]=$val;
		//$xmlphpon	.='&'.$key.'='.$val;
	}

	foreach($_SESSION['openNodes'] AS $key=>$val){
			//$_SESSION['openNodes'][$key]=$val;
			$xmlphpon	.='&'.$key.'='.$val;
	}

?>


<link rel='STYLESHEET' type='text/css' href='../common/style.css'>

<link rel="STYLESHEET" type="text/css" href="codebase/dhtmlxtree.css">
<script  src="codebase/dhtmlxcommon.js"></script>
<script  src="codebase/dhtmlxtree.js"></script>

<div id="treeboxbox_tree" style="width:100%; height:100%;background-color:#FFFFFF;border :0px solid Silver;; overflow:auto;"></div>

<script>

		var openNodes = [];

		function doOnClick(nodeId){
			//window.location = tree.getUserData(nodeId, 'myurl');


			tree.setItemColor(nodeId, 0x560000,0x00AA00);

			var myUrl = tree.getUserData(nodeId,"myurl");
			document.write('<form action='+ myUrl +' name=foo method=POST >');

			for ( var i in openNodes )
			{
				document.write('<input type=hidden name='+ i +' value='+openNodes[i] + '>');
			}

			document.write('</form>');

			document.foo.submit();



			//window.open(myUrl);


			//window.location = tree.getUserData(nodeId, 'myurl');


		}

		tree=new dhtmlXTreeObject("treeboxbox_tree","100%","100%",0);
		tree.setImagePath("codebase/imgs/csh_bluebooks/");
		tree.setXMLAutoLoading(<?php echo "'".$xmlphp."?nada=1".$xmlphpon.$menutag."'"; ?>);
		tree.loadXML(<?php echo "'".$xmlphp."?id=0".$xmlphpon.$menutag."'"; ?>);
		tree.setOnClickHandler(doOnClick);

		tree.setOnOpenHandler(treeOpenHandler);

		function treeOpenHandler(nodeId,mode){
				openNodes[nodeId] = mode?0:1;
				return true;

		};

</script>

