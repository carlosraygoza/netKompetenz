<p><br></p>
<table    class='tab'>
<tr >
	<td colspan=2 style='background-color: rgb(255, 221, 0);'>
	<b><?php echo $r['name'];?></b>
	</td>
</tr>
<tr>
	<td><?php echo $r['primary_team'];?>
	<td><?php echo $r['location'];?>
</tr>
<tr>
	<td><?php echo $r['timezone'];?>
	</td>
	<td>
	<A HREF="mailto:<? echo $r['email'];?>"><? echo $r['email'];?></A>
	</td>
</tr>
<tr>
	<td>
	</td>
	<td>
	</td>
</tr>
</table>

