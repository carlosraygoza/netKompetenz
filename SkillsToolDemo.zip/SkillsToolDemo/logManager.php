<?php
	session_start();

	$oConn = mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");
	mysql_select_db("autoapps",$oConn);

	function insertLog($action, $table, $info)
	{
		$info = json_encode($info);
		$insertQuery = "INSERT INTO log(user_id, action, table_name, info) VALUES (
							'".$_SESSION['valid_user']."',
							'$action',
							'$table',
							'$info'
						)";
		mysql_query($insertQuery);
	}
?>