<?php

include "logManager.php";

if($getListOther){
	$coreID = $getListOther;
}
else if ($getListOtherTeam OR $getListOtherLoc){

	$coreID=0;
}
else{
	$coreID 		= $_SESSION['valid_user'] ;
}


if ($coreID)
{

	mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");

	if(!$getListOther){
		if($postid){
			$query = "insert into employee_has_skill (
							 employee_coreID
							,skill_idskill
							,lvlOfExpert
							,lvlOfIntr)
					values ('$coreID','$postid','$postLvlOfExpert','$postLvlOfIntr');";
			$result = mysql_db_query("autoapps", $query);
			if($result)
			{
				// insert log
				$info = array();
				$column['employee_coreID']['newValue'] = $coreID;
				$column['skill_idskill']['newValue'] = $postid;
				$column['lvlOfExpert']['newValue'] = $postLvlOfExpert;
				$column['lvlOfIntr']['newValue'] = $postLvlOfIntr;
				array_push($info, $column);
				insertLog("insert","employee_has_skill", $info);
			}	
		}

		if(!$result){
		  $query = "UPDATE employee_has_skill
					SET lvlOfExpert='$postLvlOfExpert', lvlOfIntr='$postLvlOfIntr'
					WHERE employee_coreID='$coreID' AND skill_idskill='$postid'";
		  $result = mysql_db_query("autoapps", $query);
		}
	}
		$sortBy = $_POST['sortBy'];



	$query = "SELECT * FROM employee_all
				WHERE employee_all.coreID='$coreID'";
	$result = mysql_db_query("autoapps", $query);
	$r = mysql_fetch_array($result);

	include 'userdetails.php';

	$query = "select
				employee_has_skill.employee_coreID,
				skill.description, skill.idskill,
				employee_has_skill.lvlOfExpert, employee_has_skill.lvlOfIntr
				FROM employee_has_skill
				INNER JOIN skill
				ON skill.idskill=employee_has_skill.skill_idskill
				WHERE employee_has_skill.employee_coreID='$coreID'
				ORDER BY lvlOfExpert DESC";
	$result = mysql_db_query("autoapps", $query);

	if ($result) {



		$headers = array('Description','Lvl of Expertise','Lvl of Interest');

		writeTableTitleWithExport("", 'listEmployeeSkills', $query);
		writeTableHeader('listEmployeeSkills',$headers);

		while ($r = mysql_fetch_array($result)) {
			$coreID = $r["employee_coreID"];
			$descr = $r["description"];
			$lvlOfExpert = $r["lvlOfExpert"];
			$lvlOfIntr = $r["lvlOfIntr"];
			$idskill = $r['idskill'];

			echo "<tr>";
			writeRefTd($descr,'index.php?site=skillentry&amp;id='.$idskill);
			writeBarTd('img/bar.gif', $lvlOfExpert, 4);
			writeBarTd('img/bar.gif', $lvlOfIntr, 4);
			echo "</tr>";

		} // end of while loop

		mysql_free_result($result);

		$query = "SELECT SUM(lvlOfExpert) AS lvlOfExpert, SUM(lvlOfIntr) AS lvlOfIntr
				  FROM employee_has_skill WHERE employee_coreID='$coreID'";
		$result = mysql_db_query("autoapps", $query);
		$r = mysql_fetch_array($result);

		$sumTag = "<tr class='sortbottom'><td><b>Summation:</b></td>";
		$sumTag .= "<td><b>".$r['lvlOfExpert']."</b></td>";
		$sumTag .= "<td><b>".$r['lvlOfIntr']."</b></td>";

		$sumTag .="</tr>";



		mysql_free_result($result);

		echo $sumTag;


		writeTableEnd();




	}
	else
	{

	echo "No data.";

	} // end of if ($result)

}

if ($getListOtherTeam){



	mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");


	$query =   "SELECT MAX(sumExpert) AS maxSumExpert, MAX(sumIntr) AS maxSumIntr
				FROM
					(SELECT employee_all.primary_team, employee_all.team_id,
					employee_has_skill.skill_idskill AS id,
					skill.description,
					SUM(employee_has_skill.lvlOfExpert) AS sumExpert,
					SUM(employee_has_skill.lvlOfIntr) AS sumIntr
					FROM employee_has_skill
					INNER JOIN employee_all
					ON employee_all.coreID = employee_has_skill.employee_coreID
					INNER JOIN  skill
					ON skill.idskill=employee_has_skill.skill_idskill
					WHERE employee_all.team_id='$getListOtherTeam'
					GROUP BY employee_has_skill.skill_idskill
					ORDER BY sumExpert DESC)
				AS max";

	$result = mysql_db_query("autoapps", $query);
	$r = mysql_fetch_array($result);

	$maxSumExpert=$r['maxSumExpert']!=0?$r['maxSumExpert']:1;
	$maxSumIntr=$r['maxSumIntr']!=0?$r['maxSumIntr']:1;


	$query = "			SELECT empl.primary_team, empl.team_id,
			has_skill.skill_idskill AS id,
			skill.description,
   		SUM(has_skill.lvlOfExpert) AS sumExpert,
			SUM(has_skill.lvlOfIntr) AS sumIntr,
			MAX(has_skill.lvlOfExpert) AS maxExpert,
			team_has_skill.importance,
			numOfMem
			FROM employee_has_skill AS has_skill
			INNER JOIN employee_all AS empl
			ON empl.coreID = has_skill.employee_coreID
			INNER JOIN  skill
			ON skill.idskill=has_skill.skill_idskill
			INNER JOIN
			(SELECT employee_all.primary_team  AS team_temp ,COUNT(employee_all.location) AS numOfMem
			FROM employee_all
			GROUP BY employee_all.primary_team ) AS temp
			ON team_temp=empl.primary_team
			LEFT JOIN team_has_skill
			ON team_has_skill.skill_idskill=has_skill.skill_idskill AND team_has_skill.team_id=empl.team_id
			WHERE empl.team_id='$getListOtherTeam'
			GROUP BY has_skill.skill_idskill
			ORDER BY team_has_skill.importance DESC";

	$result = mysql_db_query("autoapps", $query);

	if ($result) {

		$headers = array('Description','Expert?', 'Importance','set' ,'Sum Level of Expertise','Avg Level of Expertise'
						,'Sum Level of Interest','Avg Level of Interest');

		writeTableTitleWithExport("team: ".$getListOtherTeam, 'teamSkillList', $query);

		echo "<form method=post action='?listOtherTeam=$getListOtherTeam&amp;setImportance=1'>";

		writeTableHeaderWithTags('teamSkillList', $headers, array('','','',"class='unsortable'",'','','',''));


		while ($r = mysql_fetch_array($result)) {
			$desc = $r['description'];
			$sumExpert = $r["sumExpert"];
			$sumIntr = $r["sumIntr"];
			$importance = $r['importance'];

			$colorTag = "rgb(255, 255, 255)";

			if($_GET['setImportance'] AND $_POST[$r['id']] != $importance){

				$query2 = "INSERT INTO team_has_skill VALUES('".$getListOtherTeam."','".$r['id']."','".$_POST[$r['id']]."')";
				$result2 = mysql_db_query("autoapps", $query2);
				if(!$result2){

					// insert log
					$info = array();
					$column['team_id']['newValue'] = $getListOtherTeam;
					$column['skill_idskill']['newValue'] = $r['id'];
					$column['importance']['newValue'] = $_POST[$r['id']];
					array_push($info, $column);
					insertLog("insert","team_has_skill", $info);

					$query2 = "UPDATE team_has_skill SET importance=".$_POST[$r['id']]." WHERE team_id='".$getListOtherTeam."' AND skill_idskill=".$r['id'];
					$result2 = mysql_db_query("autoapps", $query2);
				}

				$importance = $_POST[$r['id']];
			}

			$exExp = "no";

			if($r['maxExpert']==3){
				$exExp = "yes";
				$colorTag = "rgb(172, 181, 0)";
			}
			else {
				if($importance == 2)
					$colorTag = "rgb(208, 12, 51)";
				if($importance == 1)
					$colorTag = "rgb(242, 101, 34)";
				if($importance == 0)
					$colorTag = "rgb(255, 221, 0)";
			}



			echo "<tr>";
			writeRefTd($desc, 'index.php?site=skillentry&amp;id='.$r['id']);
			writeColoredTd($exExp, $colorTag);
			writeBarTd('img/bar.gif', $importance ,2);
			writeSelectTd($r['id'],array('low','medium','high','critical'),$importance);
			writeBarTd('img/bar.gif', $sumExpert ,$maxSumExpert);
			writeBarTd('img/bar.gif', $sumExpert/$r['numOfMem'] ,4);
			writeBarTd('img/bar.gif', $sumIntr ,$maxSumIntr);
			writeBarTd('img/bar.gif', $sumIntr/$r['numOfMem'] ,4);
			echo "</tr>";

		} // end of while loop

		echo "<tr class='sortbottom'>
							<td></td>
							<td></td>
							<td></td>
							<td>
							  <input type='image' src='img/submit.gif' value='select'>
							</td>
							<td>
							</td>
							<td>
							</td>
							<td>
							</td>
							<td>
							</td>
						</tr>";

				mysql_free_result($result);

				echo "</table></table>";
		echo "</form>";

		}

}


if ($getListOtherLoc){
	echo "Location: ".$getListOtherLoc."<br>";

	mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");


	$query =   "SELECT MAX(sumExpert) AS maxSumExpert, MAX(sumIntr) AS maxSumIntr
				FROM
					(SELECT employee_all.location,
					employee_has_skill.skill_idskill AS id,
					skill.description,
					SUM(employee_has_skill.lvlOfExpert) AS sumExpert,
					SUM(employee_has_skill.lvlOfIntr) AS sumIntr
					FROM employee_has_skill
					INNER JOIN employee_all
					ON employee_all.coreID = employee_has_skill.employee_coreID
					INNER JOIN  skill
					ON skill.idskill=employee_has_skill.skill_idskill
					WHERE employee_all.location_id='$getListOtherLoc'
					GROUP BY employee_has_skill.skill_idskill
					ORDER BY sumExpert DESC)
				AS max";

	$result = mysql_db_query("autoapps", $query);
	$r = mysql_fetch_array($result);

	$maxSumExpert=$r['maxSumExpert']!=0?$r['maxSumExpert']:1;
	$maxSumIntr=$r['maxSumIntr']!=0?$r['maxSumIntr']:1;

	$query = "SELECT empl.location, empl.location_id,
			has_skill.skill_idskill AS id,
			skill.description,
   			SUM(has_skill.lvlOfExpert) AS sumExpert,
			SUM(has_skill.lvlOfIntr) AS sumIntr,
			numOfMem
			FROM employee_has_skill AS has_skill
			INNER JOIN employee_all AS empl
			ON empl.coreID = has_skill.employee_coreID
			INNER JOIN  skill
			ON skill.idskill=has_skill.skill_idskill
			INNER JOIN
			(SELECT employee_all.location  AS location_temp ,COUNT(employee_all.location) AS numOfMem
			FROM employee_all
			GROUP BY employee_all.location ) AS temp
			ON location_temp=empl.location
			WHERE empl.location_id='$getListOtherLoc'
			GROUP BY has_skill.skill_idskill
			ORDER BY sumExpert DESC";

	$result = mysql_db_query("autoapps", $query);

	if ($result) {

			$headers = array('Description','Sum Level of Expertise','Avg Level of Expertise'
							,'Sum Level of Interest','Avg Level of Interest');

			writeTableTitleWithExport("Location: ".$getListOtherLoc, 'locationSkillList', $query);
			writeTableHeader('locationSkillList', $headers);


			while ($r = mysql_fetch_array($result)) {
				$desc = $r['description'];
				$sumExpert = $r["sumExpert"];
				$sumIntr = $r["sumIntr"];


				echo "<tr>";
				writeRefTd($desc, 'index.php?site=skillentry&amp;id='.$r['id']);
				writeBarTd('img/bar.gif', $sumExpert ,$maxSumExpert);
				writeBarTd('img/bar.gif', $sumExpert/$r['numOfMem'] ,4);
				writeBarTd('img/bar.gif', $sumIntr ,$maxSumIntr);
				writeBarTd('img/bar.gif', $sumIntr/$r['numOfMem'] ,4);
				echo "</tr>";

			} // end of while loop

			mysql_free_result($result);

			writeTableEnd();
	}



};

?>