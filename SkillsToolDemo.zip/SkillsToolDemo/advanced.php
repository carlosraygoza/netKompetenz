<br>
<h4>advanced</h4>
<form method='post' action=''>
	<textarea name='sql' rows="10" cols="60"><?php echo stripslashes($_POST['sql']); ?></textarea>
	<br>
	<input type='submit' value='submit'>
<form>


<?php
if($_POST['sql']){

	$headers = array();

	mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");


	$select = $_POST['sql'];
	$select = stripslashes($select);


	$result = mysql_db_query("autoapps", $select);

	$num_fields = mysql_num_fields($result);
	for($i=0; $i<$num_fields; $i++)
	{
		$headers[$i] = mysql_field_name($result, $i)."   ";
	}


	writeTableHeader('custom', $headers);

	while($r = mysql_fetch_array($result)){
		echo "<tr>";
			for($i=0;$i<$num_fields; $i++){
				writeSimpleTd($r[$i]);
			}
		echo "</tr>";
	}

	writeTableEnd();
}


?>