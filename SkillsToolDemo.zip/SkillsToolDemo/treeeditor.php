<?php

$postAction = $_POST['action'];
$postSkilldesc = $_POST['skilldesc'];
$postDetaileddesc = $_POST['detaileddesc'];
$postEditoradd = $_POST['editoradd'];
$getAction = $_GET['action'];

//get all info

$sourceid = $_GET['id'];
$sourcepid = $_GET['pid'];
if($sourceid AND $sourcepid)
	$hasSource = 1;

$targetid = $_GET['targetid'];
$targetpid = $_GET['targetpid'];
if(1)
	$hasTarget = 1;

if($sourceid AND ($postAction=='copy' OR $postAction=='move'))
	$showTargetTree = 1;
else
	$showTargetTree = 0;

//get the info from the selected source node

echo "Source ID ".$sourceid;

if($sourceid){
	mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");

	$select = "SELECT * FROM skill WHERE skill.idskill=$sourceid ";
	$result = mysql_db_query("autoapps", $select);
	$r = mysql_fetch_array($result);

	$sourceiddesc = $r['description'];
	$sourceiddetaileddesc = $r['detailedDesc'];


	$select = "SELECT * FROM skill WHERE skill.idskill=$sourcepid ";
	$result = mysql_db_query("autoapps", $select);
	$r = mysql_fetch_array($result);

	$sourcepiddesc = $r['description'];
}







//do the right work

if($getAction=='copy' and $sourceid and $hasTarget){
	echo "I'll copy";
	$select = "INSERT INTO skill_has_skill (skill_idskill, skill_idskill1) VALUES ('$targetid', '$sourceid')";
	$result = mysql_db_query("autoapps", $select);
	echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?site=treeeditor&amp;id=$sourceid&amp;pid=$sourcepid'>";


}
else if($getAction=='move' and $sourceid and $hasTarget){
	echo "I'll move";
	$select = "INSERT INTO skill_has_skill (skill_idskill, skill_idskill1) VALUES ('$targetid', '$sourceid')";
	$result = mysql_db_query("autoapps", $select);
	if($result){
		$select = "DELETE FROM skill_has_skill WHERE (skill_idskill='$sourcepid' AND skill_idskill1='$sourceid') ";
		$result = mysql_db_query("autoapps", $select);
		echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?site=treeeditor&amp;id=$sourceid&amp;pid=$sourcepid'>";
	}
}
else if($postAction=='delete' and $sourceid){
	echo "I'll delete";
	$select = "DELETE FROM skill_has_skill WHERE (skill_idskill='$sourcepid' AND skill_idskill1='$sourceid') ";
	$result = mysql_db_query("autoapps", $select);
	$select = "DELETE FROM skill WHERE (idskill='$sourceid') ";
	$result = mysql_db_query("autoapps", $select);
	echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?site=treeeditor'>";
}
else if($postEditoradd=='add' and $sourceid){
	echo "I'll add<br>";
	echo $postSkilldesc."<br>";
	echo $postDetaileddesc."<br>";
	$select = "INSERT INTO skill (description, detailedDesc) VALUES ('$postSkilldesc', '$postDetaileddesc') ";
	$result = mysql_db_query("autoapps", $select);
	if($result){
		$insertid = mysql_insert_id();
		$select = "INSERT INTO skill_has_skill (skill_idskill, skill_idskill1) VALUES ('$sourceid', '$insertid') ";
		echo $select;
		$result = mysql_db_query("autoapps", $select);
		echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?site=treeeditor&amp;id=$sourceid&amp;pid=$sourcepid'>";
	}

}
else if($postEditoradd=='edit' and $sourceid){
	echo "I'll edit <br>";
	echo $postSkilldesc."<br>";
	echo $postDetaileddesc."<br>";

	$select = "UPDATE skill SET description='$postSkilldesc', detailedDesc='$postDetaileddesc' WHERE idskill='$sourceid'";
	$result = mysql_db_query("autoapps", $select);

	$sourceiddesc = $postSkilldesc;
	$sourceiddetaileddesc = $postDetaileddesc;
	echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?site=treeeditor&amp;id=$sourceid&amp;pid=$sourcepid'>";

}
else{

}


?>


<br>


<table border=0 >
<tr>
	<td  valign=top>
		<h4>edit the skill tree</h4>

		<?php
		echo '<h6>Source: '.$sourceiddesc.'<br>';
		echo 'Parent: '.$sourcepiddesc.'<br></h6>';
		?>
		<table class='tab' width=400px>
			<tr>
				<td><h5>move, copy or delete node</h5>
					<?php
						if(!$sourceid)
							echo 'no source node selected';
						else if($sourceid AND !$postAction){

							echo "<form method='POST' action='".$_SERVER['REQUEST_URI']."' >
								<select name='action'>
									<option value='copy'>copy</option>
									<option value='move'>move</option>
									<option value='delete'>delete</option>
								</select>
								<input type='image' src='img/submit.gif' value='submit'>
							</form>";
						}
						else if($sourceid AND $postAction){
							echo "<a href='".$_SERVER['REQUEST_URI']."'>cancel</a>";
						}
					?>
				</td>
				<td>
				</td>
			</tr>
			<tr>
				<td>
				<?php
				if($postAction!='move' AND $postAction!='copy'){
					echo "<h5>add new sub node</h5>";

						if($sourceid){
							echo "<form method='post' action='index.php?site=treeeditor&amp;id=".$sourceid."&amp;pid=".$sourcepid."'>
							<p>Skill Name:<br><input name='skilldesc' type='text' size='30' maxlength='30'></p>
							<p>Detailed Description:<br><textarea name='detaileddesc' cols='50' rows='10'></textarea></p>
							<input type='hidden' name='editoradd' value='add'>
							<input type='image' src='img/submit.gif' value='submit'>
							</form>";
						}
						else
							echo 'no source node selected';

				}
				?>
				</td>

				<td>
				<?php
				if($postAction!='move' AND $postAction!='copy'){
					echo "<h5>edit node</h5>";

						if($sourceid){
							echo "<form method='post' action='index.php?site=treeeditor&amp;id=".$sourceid."&amp;pid=".$sourcepid."'>
							<p>Skill Name:<br><input name='skilldesc' type='text' value='".$sourceiddesc."' size='30' maxlength='30'></p>
							<p>Detailed Description:<br><textarea name='detaileddesc' cols='50' rows='10'>".$sourceiddetaileddesc."</textarea></p>
							<input type='hidden' name='editoradd' value='edit'>
							<input type='image' src='img/submit.gif' value='submit'>
							</form>";
						}
						else
							echo 'no source node selected';

				}

				?>
				</td>
			</tr>
		</table>
	</td>
	<td valign=top>
		<?php
			if($showTargetTree)
				include 'targettree.php';
		?>
	</td>
</tr>
</table>