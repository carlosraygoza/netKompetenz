<?php
	$xmlphp = 'xml.php';
	//echo $_POST['182_100'];
	//$_SESSION['post'] = $_POST;
	//echo $_SESSION['post'];

	if($_GET['site']=='groupeditor'){
		$menutag="&site=groupeditor&addGroupSkill=1";
		//$addSkillToGroupTag = " >>";
	}
	else if($_GET['site']=='treeeditor'){
		$menutag="&site=treeeditor";
		//$addSkillToGroupTag = " >>";
	}
	else
	$menutag="&site=skillentry";

	foreach($_POST AS $key=>$val){
		$xmlphpon	.='&'.$key.'='.$val;
	}

?>


<link rel='STYLESHEET' type='text/css' href='../common/style.css'>

<link rel="STYLESHEET" type="text/css" href="codebase/dhtmlxtree.css">
<script  src="codebase/dhtmlxcommon.js"></script>
<script  src="codebase/dhtmlxtree.js"></script>

<div id="targettreeboxbox_tree" style="width:100%; height:100%;background-color:#FFFFFF;border :0px solid Silver;; overflow:auto;"></div>

<script>

		var openNodes = [];

		function targetdoOnClick(nodeId){
			//window.location = targettree.getUserData(nodeId, 'myurl');


			targettree.setItemColor(nodeId, 0x560000,0x00AA00);

			var target = targettree.getUserData(nodeId,"target");
			document.write('<form action=<? echo  $_SERVER['REQUEST_URI']."&action=".$postAction."&targetid="; ?>' + target  +' name=foo method=POST >');

			for ( var i in openNodes )
			{
				document.write('<input type=hidden name='+ i +' value='+openNodes[i] + '>');
			}

			document.write('</form>');

			document.foo.submit();



			//window.open(myUrl);


			//window.location = targettree.getUserData(nodeId, 'myurl');


		}

		targettree=new dhtmlXTreeObject("targettreeboxbox_tree","100%","100%",0);
		targettree.setImagePath("codebase/imgs/csh_bluebooks/");
		targettree.setXMLAutoLoading(<? echo "'".$xmlphp."?nada=0".$xmlphpon.$menutag."'"; ?>);
		targettree.loadXML(<? echo "'".$xmlphp."?id=0".$xmlphpon.$menutag."'"; ?>);
		targettree.setOnClickHandler(targetdoOnClick);

		targettree.setOnOpenHandler(targettreeOpenHandler);

		function targettreeOpenHandler(nodeId,mode){
				openNodes[nodeId] = mode?0:1;
				return true;

		};

</script>

