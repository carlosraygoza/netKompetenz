<?php

	$treePlugins = '"plugins" : [ 
						"search",
						"types",
						"sort"
					 ]';


	if(!$_SESSION['openNodes']){
		$_SESSION['openNodes'] = array();
	}

	if($_GET['site']=='groupeditor'){
		$menutag="&site=groupeditor&addGroupSkill=1";
	}
	else if($_GET['site']=='treeeditor'){
		$menutag="&site=treeeditor";
		$treePlugins = '"plugins" : [ 
							"contextmenu", 
							"search",
							"dnd",
							"unique",
							"types",
							"sort"
						 ]';
	}
	else if($_GET['site']=='changeSkill'){
			$menutag="&site=changeSkill";
	}
	else
		$menutag="&site=skillentry";

	foreach($_POST AS $key=>$val){
		$_SESSION['openNodes'][$key]=$val;
		//$xmlphpon	.='&'.$key.'='.$val;
	}

	foreach($_SESSION['openNodes'] AS $key=>$val){
			//$_SESSION['openNodes'][$key]=$val;
			$xmlphpon	.='&'.$key.'='.$val;
	}

?>
<link rel="stylesheet" href="_Sources/jstree/dist/themes/default/style.min.css" />
<script src="_Sources/jquery/jquery.min.js"></script>
<script src="_Sources/jstree/dist/jstree.min.js"></script>

<b>Search skill:</b> <input id="search" type="text"/>
<div id="treeboxbox_tree" style="width:100%; height:100%;background-color:#FFFFFF;border :0px solid Silver;; overflow:auto;"></div>

<script>
// inline data demo

	var onLoadFlag = true;
	$.jstree.defaults.contextmenu.select_node = false;
	$('#treeboxbox_tree')
		.on("loaded.jstree", function (e, data) {
			<?php
			if(isset($_GET['id']))
			{
				echo "data.instance.select_node(".$_GET['treeId'].");";
			}
			echo "onLoadFlag = false;";
			?>
		})
		.bind("select_node.jstree", function(evt, data){
			if(!onLoadFlag)
			{
	        	var openNodes = data.selected;
	        	var selectedNode = data.node.id;
	        	var parentNode = data.node.parent

	        	var myUrl = getFormURL(data.node.data.skillid, data.node.data.parentid, data.node.id);



	        	document.write('<form action='+ myUrl +' name=foo method=POST >');

				for ( var i in openNodes )
				{
					document.write('<input type=hidden name='+ i +' value='+openNodes[i] + '>');
				}

				document.write('</form>');

				document.foo.submit();

	            //selected node object: data.inst.get_json()[0];
	            //selected node text: data.inst.get_json()[0].data
	        }
        })
		.jstree({
		'core' : {
			"check_callback" : function (operation, node, parent, position, more) {
		      	if(operation == "create_node"){
		      		var nodeName = prompt("Please enter the new skil name:","");
	                if(nodeName != '' && nodeName != null)
	                {
	                	$.ajax({
                			url : "NodeToDBManager.php",
                			type : 'post',
                			data : {
                				'action':'create',
                				'nodeName':nodeName,
                				'parent':parent.data.skillid
                			},
                			success: function(result){
						        var data = JSON.parse(result);
						        if(data.success != false)
						        {
						        	location.href = getFormURL(data.success.skillid, parent.data.parentid,data.success.treeid);
						        }
						    }
	                	})
	                }
	                else
	                {
	                	return false;
	                }
		      	}
		      	else if(operation == "rename_node"){
                    if(position != node.text)
                    {
                    	$.ajax({
                			url : "NodeToDBManager.php",
                			type : 'post',
                			data : {
                				'action':'rename',
                				'node':node.data.skillid,
                				'newName':position
                			},
                			success: function(result){
						        var data = JSON.parse(result);
						        if(data.success != false)
						        {
						        	location.reload();
						        }
						    }
	                	})
                    }
                    else{
                    	return false;
                    }
		      	}
		      	else if(operation == "delete_node"){
		      		var allow = confirm("Are you sure to delete "+node.text+"?");
		      		if(allow)
		      		{
			      		$.ajax({
	            			url : "NodeToDBManager.php",
	            			type : 'post',
	            			data : {
	            				'action':'delete',
	            				'node':node.id
	            			},
	            			success: function(result){
						        var data = JSON.parse(result);
						        if(data.success != false)
						        {
						        	location.href = getFormURL(parent.data.skillid, parent.data.parentid, parent.id);
						        }
						    }
	                	})
			      	}
			      	else{
			      		return false;
			      	}
		      	}
		      	else if(operation == "copy_node"){
		      		if(node.parent == parent.id){
		      			return false;
		      		}
		      		else{
			      		$.ajax({
		        			url : "NodeToDBManager.php",
		        			type : 'post',
		        			data : {
		        				'action':'copy',
		        				'node':node.data.skillid,
		        				'parent':parent.data.skillid
		        			},
		        			success: function(result){
						        var data = JSON.parse(result);
						        if(data.success != false)
						        {
						        	location.href = getFormURL(node.data.skillid, parent.data.skillid, data.success);
						        }
						    }
		            	})
			      	}
		      	}
		      	else if(operation == "move_node" && !('dnd' in more)){
		      		if(node.parent == parent.id){
		      			return false;
		      		}
		      		else{
			      		$.ajax({
		        			url : "NodeToDBManager.php",
		        			type : 'post',
		        			data : {
		        				'action':'move',
		        				'node':node.data.skillid,
		        				'parent':parent.data.skillid,
		        				'relationID':node.id
		        			},
		        			success: function(result){
						        var data = JSON.parse(result);
						        if(data.success != false)
						        {
						        	location.href = getFormURL(node.data.skillid, parent.data.skillid, data.success);
						        }
						    }
		            	})
			      	}
		      	}

		      	return true; // allow everything else
		    },
			'data' : {
				'url' : 'JSONTree.php',
			    'dataType' : 'json'
			}
		},
		"types":{
			"child" : {
				"icon" : "jstree-file",
		    },
		    "parent" : {
				"icon" : "jstree-folder",
		    }
		},
		<?php
			echo $treePlugins;
		?>
	});

	function getFormURL(selectedNode, parentNode, treeId){
		<?php
		if($_GET['site'] == "groupeditor")
		{
			$site = "?site=groupeditor&addGroupSkill=1";
		}
		else
		{
			$site = str_replace("&", "?", $menutag);
		}
		?>
		// get Current URL
		var myUrl = window.location.href;
		var site = '<?php echo $site; ?>';

    	// erase params
    	myUrl = myUrl.split('?')[0];

    	// add new params to url
    	myUrl = myUrl + site + "&id=" + selectedNode + "&pid=" + parentNode + "&treeId=" + treeId;

    	return myUrl;
	}


	var to = false;

	$('#search').keyup(function(){

		if(to) {clearTimeout(to);}

		to = setTimeout(function(){
			var v = $("#search").val();
			$("#treeboxbox_tree").jstree(true).search(v);
		},
		250);
	});
	

</script>

