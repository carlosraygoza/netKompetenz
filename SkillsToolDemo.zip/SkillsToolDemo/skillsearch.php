<br>
<h4>search skill</h4>
enter words to search for seperated by commas<br>

<form method='post' action=''>
	<textarea name='searchedstring' rows="2" cols="60"><?php echo stripslashes($_POST['searchedstring']); ?></textarea>
	<br>
	<input type='submit' value='search'>
<form>
<br>


<?php
if($_POST['searchedstring']){

	$headers = array();

	mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");


	$search = $_POST['searchedstring'];
	$search = stripslashes($search);
	$search = ltrim($search);
	$search  = str_replace(array(' ','\n'), '', $search );

	$searchwords = explode(',',$search);


	$searchTag = '';

	foreach($searchwords AS $word){
		$searchTag .= " OR skill.description LIKE '%".$word."%' OR skill.detailedDesc LIKE '%".$word."%'";
	}


	$query =  "SELECT * FROM skill
				WHERE FALSE ".$searchTag;

	$result = mysql_db_query("autoapps", $query);

	writeTableHeader('search', array('name','detailed description'));

	while($r = mysql_fetch_array($result)){

		$description = $r['description'];
		$detailedDescription = $r['detailedDesc'];

		foreach($searchwords AS $word){
				$description = str_ireplace($word, '<b>'.$word.'</b>', $description );
				$detailedDescription = str_ireplace($word, '<b>'.$word.'</b>', $detailedDescription );
		}


		echo "<tr>";
			writeRefTd($description, "index.php?site=skillentry&amp;id=".$r['idskill']);
			writeSimpleTd($detailedDescription);
		echo "</tr>";
	}

	writeTableEnd();
}


?>