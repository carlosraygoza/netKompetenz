<?php

include "logManager.php";

$fcontents = file ('exceldata.txt');

mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");


for ($i=1; $i<sizeof($fcontents); $i++){


$line = trim($fcontents[$i]);

$array = explode(',',$line);

echo $array[0]."+".$array[1]."+".$array[2]."+".$array[3]."<br>";

$coreID;
$skill;
$expert;

//convert name to coreID
$query = "SELECT coreID
FROM employee
WHERE employee.Name='$array[0]'";
$result = mysql_db_query("autoapps", $query);
if($result){
	$r = mysql_fetch_array($result);


	$coreID = $r['coreID'];
	echo "coreID: ".$coreID."<br>";


}
else{
	echo "failure converting ".$array[0]." to coreID<br>";
	$coreID = '';
}


//convert skill name to skillID

$array[1] = str_replace("'","\'",$array[1]);

$query = "SELECT skill.idskill
FROM skill
WHERE skill.description='$array[1]'";
$result = mysql_db_query("autoapps", $query);
if($result){
	$r = mysql_fetch_array($result);


	$skill = $r['idskill'];
	echo "skill: ".$skill."<br>";


}
else{
	echo "failure converting ".$array[1]." to skill<br>";
	$skill = '';
}


$expert = round($array[2]);

echo $expert."<br>";



$query = "insert into employee_has_skill values ('$coreID','$skill','$expert','0','0');";
$result = mysql_db_query("autoapps", $query);


if(!$result){
	// insert log
	$info = array();
	$column['employee_coreID']['newValue'] = $coreID;
	$column['skill_idskill']['newValue'] = $skill;
	$column['lvlOfExpert']['newValue'] = $expert;
	$column['lvlOfIntr']['newValue'] = 0;
	array_push($info, $column);
	insertLog("insert","employee_has_skill", $info);

	 $query = "UPDATE employee_has_skill
			SET lvlOfExpert='$expert', lvlOfIntr='0', actWorkld='0'
			WHERE employee_coreID='$coreID' AND skill_idskill='$skill'";
	 $result = mysql_db_query("autoapps", $query);
}

if(!result){
	echo "++++++++++FAILURE INSERTING SKILL ".$skill." TO ".$coreID."++++++++++++";

}



}

?>