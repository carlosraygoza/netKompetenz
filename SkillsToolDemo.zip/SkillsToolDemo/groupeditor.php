<?php
include "logManager.php";

mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");

if($_POST['selectgroup'])
	$_SESSION['selectgroup'] = $_POST['selectgroup'];
if($_POST['newgroup'] AND $_POST['newgroup'] != 'or create group' AND $_POST['newgroup'] != ''){
	$newgroup = $_POST['newgroup'];
	$query = "INSERT INTO autoapps.group (name) VALUES('".$newgroup."')";
	$result = mysql_db_query("autoapps", $query);
	if($result)
	{
		$_SESSION['selectgroup'] = mysql_insert_id();

		// insert log
		$info = array();
		$column['name']['newValue'] = $newgroup;
		array_push($info, $column);
		insertLog("insert","group", $info);
	}
}

$selectedGroupId = $_SESSION['selectgroup'];



?>


<br>
<h4>Group editor</h4>
Select or Create Group:
<table class='tab' ><tr><td >
<table class='no_lines'>
<tr>
	<td>
		<form method='post' action='?site=groupeditor'>
		<select name='selectgroup'  onChange='this.form.submit();'> ";
		<option value=''>Select group</option>
		<?php
		mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");
		$select = "SELECT * from autoapps.group";
		$result = mysql_db_query("autoapps", $select);
		while($r = mysql_fetch_array($result)){
			if($r['id']==$selectedGroupId)
				$select = "selected";
			else
				$select = "";

			echo "<option $select value='".$r['id']."'>".$r['name']."</option> \n";
		}
		?>
		</select>
	</td>
	<td valign='bottom'>

		</form>
	</td>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</td>
	<td>
	<form method='post' action='?site=groupeditor'>
	<input name="newgroup" type="text" value="or create group" size="30" maxlength="40">
	</td>
	<td valign='bottom'>
		<input type="image" src="img/submit.gif" value="select">
		</form>
	</td>
	<td>
	</td>
</tr>
</table>
</td></tr></table>

<?php

if($selectedGroupId){


$filterTag = '';

if($_SESSION['teamFilter'])
	$filterTag = " AND primary_team_id='".$_SESSION['teamFilter']."'";
if($_SESSION['locationFilter'])
	$filterTag .= " AND location_id='".$_SESSION['locationFilter']."'";
echo $filterTag;

if($_POST['employeesToAdd']){
	foreach($_POST['employeesToAdd'] AS $coreID){
		$query = "INSERT INTO group_has_employee VALUES(".$selectedGroupId.",'".$coreID."')";
		$result = mysql_db_query("autoapps", $query);
		if($result)
		{
			// insert log
			$info = array();
			$column['group_id']['newValue'] = $selectedGroupId;
			$column['employee_coreID']['newValue'] = $coreID;
			array_push($info, $column);
			insertLog("insert","group_has_employee", $info);
		}
	}
}


if($_GET['addGroupSkill']){
	$query = "INSERT INTO group_has_skill VALUES(".$selectedGroupId.",".$_GET['id'].",0)";
	$result = mysql_db_query("autoapps", $query);
	if($result)
	{
		// insert log
		$info = array();
		$column['group_id']['newValue'] = $selectedGroupId;
		$column['skill_idskill']['newValue'] = $$_GET['id'];
		$column['importance']['newValue'] = 0;
		array_push($info, $column);
		insertLog("insert","group_has_skill", $info);
	}
}


if($_GET['deleteGroupMem']){
	$query = "DELETE FROM group_has_employee WHERE (group_id=$selectedGroupId AND employee_coreID='".$_GET['deleteGroupMem']."') ";
	$result = mysql_db_query("autoapps", $query);
	if($result)
	{
		// insert log
		$info = array();
		$column['WHERE']['group_id'] = $selectedGroupId;
		$column['WHERE']['employee_coreID'] = $_GET['deleteGroupMem'];
		array_push($info, $column);
		insertLog("delete","group_has_employee", $info);
	}
}

if($_GET['deleteGroupSkill']){
	$query = "DELETE FROM group_has_skill WHERE (group_id=$selectedGroupId AND skill_idskill='".$_GET['deleteGroupSkill']."') ";
	$result = mysql_db_query("autoapps", $query);
	if($result)
	{
		// insert log
		$info = array();
		$column['WHERE']['group_id'] = $selectedGroupId;
		$column['WHERE']['skill_idskill'] = $_GET['deleteGroupSkill'];
		array_push($info, $column);
		insertLog("delete","group_has_skill", $info);
	}
}

if($_GET['setImportance']){
	$query = "SELECT * FROM group_has_skill WHERE group_has_skill.group_id=$selectedGroupId";
	$result = mysql_db_query("autoapps", $query);
	while($r=mysql_fetch_array($result)){
		$oldImportance = $r['importance'];

		$query2 = "UPDATE group_has_skill SET importance=".$_POST[$r['skill_idskill']]." WHERE group_id=".$selectedGroupId." AND skill_idskill=".$r['skill_idskill'];
		//echo $query2."<br>";
		if(mysql_db_query("autoapps", $query2))
		{
			// insert log
			$info = array();
			$column['importance']['oldValue'] = $oldImportance;
			$column['importance']['newValue'] = $_POST[$r['skill_idskill']];
			$column['WHERE']['group_id'] = $selectedGroupId;
			$column['WHERE']['skill_idskill'] = $r['skill_idskill'];
			array_push($info, $column);
			insertLog("update","group_has_skill", $info);
		}
	}
}

echo "<br><br>Add Team Members:<table class='tab' ><tr><td><br>
	<form method=post action='?site=groupeditor'>
	<select name='employeesToAdd[]' size='10' multiple>";

		$select = "SELECT coreID,
					name,
					primary_team_id
					FROM employee
					WHERE TRUE $filterTag
					ORDER BY name";

	echo $select;
		$result = mysql_db_query("autoapps", $select);

	while($r = mysql_fetch_array($result)){
		echo '<option value='.$r['coreID'].'><b>'.$r['name'].'</b>, '.$r['primary_team_id'].'</option>';

	}


echo "	</select><br>
<input type='image' src='img/add.gif' value='select'><br>
</form>
</td></tr></table><br>";


	$select = "SELECT
				coreID,
				name,
				primary_team_id,
				location_id
				FROM group_has_employee
				INNER JOIN employee
				ON group_has_employee.employee_coreID=employee.coreID
				WHERE group_has_employee.group_id=$selectedGroupId
				ORDER BY name";
	$result = mysql_db_query("autoapps", $select);

	writeTableTitleWithExport("Group Members:", 'groupmembers', $select);
	writeTableHeaderWithTags('groupmembers',array('del','name','team','location'), array("class='unsortable'",'','',''));

	if(mysql_num_rows($result))
		$hasMembers = 1;
	else
		$hasMembers = 0;

	while($r = mysql_fetch_array($result)){
		echo "<tr>";

		writeRefTd("<img src='img/delete.jpg'>", 'index.php?site=groupeditor&amp;deleteGroupMem='.$r['coreID']); 
		writeRefTd($r['name'], 'index.php?site=changeSkill&amp;listOther='.$r['coreID']);
		writeRefTd($r['primary_team_id'], 'index.php?site=changeSkill&amp;listOtherTeam='.$r['primary_team']);
		writeRefTd($r['location_id'], 'index.php?site=changeSkill&amp;listOtherLoc='.$r['location']);
		echo "</tr>";
	}

	echo "</table></table>";

	$select = "SELECT
				MAX(sumExpert) AS maxSumExpert,
				MAX(sumIntr) AS maxSumIntr
				FROM skill
				INNER JOIN group_has_skill
				ON skill.idskill=group_has_skill.skill_idskill
				INNER JOIN (
					SELECT employee_has_skill.skill_idskill AS sumIdskill
					,SUM(lvlOfExpert) AS sumExpert
					,SUM(lvlOfIntr) AS sumIntr
					FROM employee_has_skill
					GROUP BY employee_has_skill.skill_idskill) AS sumSkills
				ON sumIdskill=skill.idskill";

	$result = mysql_db_query("autoapps", $select);

	$r = mysql_fetch_array($result);

	$maxSumExpert=$r['maxSumExpert']!=0?$r['maxSumExpert']:1;
	$maxSumIntr=$r['maxSumIntr']!=0?$r['maxSumIntr']:1;


	if($hasMembers){
	$select = "SELECT j3idskill AS idskill,
				j3group_id AS group_id,
				description,
				importance,
				numOfMem,
				SUM(lvlOfExpert) AS sumExpert,
				MAX(lvlOfExpert) AS maxExpert,
				SUM(lvlOfIntr) AS sumIntr
				FROM
				(SELECT * FROM
					(SELECT group_has_employee.employee_coreID AS j1coreID,
					skill_idskill AS j1idskill,
					lvlOfExpert,
					lvlOfIntr
					FROM group_has_employee
					INNER JOIN employee_has_skill
					ON group_has_employee.employee_coreID= employee_has_skill.employee_coreID
					WHERE group_id=$selectedGroupId) as j1
				RIGHT JOIN
					(SELECT skill_idskill AS j3idskill,
					group_has_skill.group_id AS j3group_id,
					skill.description,
					importance
					FROM group_has_skill
					INNER JOIN skill
					ON skill.idskill=group_has_skill.skill_idskill
					WHERE group_has_skill.group_id=$selectedGroupId ) as j3
				ON j1idskill=j3idskill ) as j2
				RIGHT JOIN
				(SELECT COUNT(group_has_employee.group_id) AS numOfMem, group_has_employee.group_id AS j4group_id
				FROM group_has_employee
				WHERE group_has_employee.group_id=$selectedGroupId ) AS j4
				ON j4group_id=j3group_id
				GROUP BY j3idskill";
	}
	else{
		$select="SELECT
					skill.idskill,
					group_has_skill.group_id,
					skill.description,
					group_has_skill.importance,
					1 AS numOfMem,
					0 AS sumExpert,
					0 AS maxExpert,
					0 AS sumIntr
					FROM group_has_skill
					INNER JOIN skill
					ON skill.idskill=group_has_skill.skill_idskill
					WHERE group_has_skill.group_id=$selectedGroupId";
	}



	$result = mysql_db_query("autoapps", $select);



	$headers = array('del','Description','Expert?', 'Importance','set Import.','Sum Level of Expertise','Avg Level of Expertise'
						,'Sum Level of Interest','Avg Level of Interest');

		writeTableTitleWithExport("Group Skills:", 'skillsOfGroup', $select);


		echo "<form method=post action='?site=groupeditor&amp;setImportance=1'>";

		writeTableHeaderWithTags('skillsOfGroup', $headers, array("class='unsortable'",'','','',"class='unsortable'",'','',''));

		while ($r = mysql_fetch_array($result)) {
			$desc = $r['description'];
			$sumExpert = $r["sumExpert"];
			$sumIntr = $r["sumIntr"];
			$importance = $r['importance'];

			$colorTag = "rgb(255, 255, 255)";

			$exExp = "no";

			if($r['maxExpert']>=3){
				$exExp = "yes";
				$colorTag = "rgb(172, 181, 0)";
			}
			else {
				if($importance >= 2)
					$colorTag = "rgb(208, 12, 51)";
				if($importance == 1)
					$colorTag = "rgb(242, 101, 34)";
				if($importance == 0)
					$colorTag = "rgb(255, 221, 0)";
			}

			echo "<tr>";
			writeRefTd("<img src='img/delete.jpg'>",  'index.php?site=groupeditor&amp;deleteGroupSkill='.$r['idskill']);
			writeRefTd($desc, 'index.php?site=skillentry&amp;id='.$r['idskill']);
			writeColoredTd($exExp, $colorTag);
			writeBarTd('img/bar.gif', $importance ,2);
			writeSelectTd($r['idskill'],array('low','medium','high','critical'),$importance);
			writeBarTd('img/bar.gif', $sumExpert ,$maxSumExpert);
			writeBarTd('img/bar.gif', $sumExpert/$r['numOfMem'] ,4);
			writeBarTd('img/bar.gif', $sumIntr ,$maxSumIntr);
			writeBarTd('img/bar.gif', $sumIntr/$r['numOfMem'] ,4);
			echo "</tr>";

		} // end of while loop

		echo "<tr class='sortbottom'>
					<td>
					</td>
					<td>
					</td>
					<td>
					</td>
					<td>
					</td>
					<td>
					  <input type='image' src='img/submit.gif' value='select'>
					</td>
					<td>
					</td>
					<td>
					</td>
					<td>
					</td>
					<td>
					</td>
				</tr>";

		mysql_free_result($result);

		echo "</table></table>";
		echo "</form>";






}



?>