<?php 

if(isset($_POST['uid']))
{
	try {
		$conn = ldap_connect("HI2C102A.cw01.contiwan.com") or die("Could not connect");

		$auth = @ldap_bind($conn,$_POST['uid']."@cw01.contiwan.com",$_POST['pass']);

		if ($auth) 
		{
			echo "Credenciales correctas";
		}
		else
		{
			echo "incorrectas";
		}
		
	} catch (Exception $e) 
	{
		echo "Credenciales incorrectas<br>";	

		echo $e;
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post">
	<table>
		<tr>
			<td><label>UID:</label></td>
			<td><input type="text" name="uid"></td>
		</tr>
		<tr>
			<td><label>Pass:</label></td>
			<td><input type="password" name="pass"></td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" value="submit"></td>
		</tr>
	</table>
	</form>
</body>
</html>