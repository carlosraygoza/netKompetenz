<?php 

	$oConn = mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");
	mysql_select_db("autoapps",$oConn);

	// Start with root
	$rows = getChildren('0');

	// Print JSON String
	echo json_encode($rows);

	/**
	 * Recoursive function to get children by an item's id
	 */
	function getChildren($id)
	{
		// children array
		$item = array();
		$childrenQuery = mysql_query("SELECT * FROM skill_has_skill shs INNER JOIN skill s ON shs.skill_idskill1 = s.idskill WHERE shs.skill_idskill = $id");

		while($child = mysql_fetch_assoc($childrenQuery))
		{
			$itemChild = array();
			$itemChild['id'] = $child['idshs'];
			$itemChild['text'] = $child['description'];
			$itemChild['data']['skillid'] = $child['idskill'];
			$itemChild['data']['parentid'] = $child['skill_idskill'];

			$children = getChildren($child['idskill']);
			if(!empty($children))
			{
				$itemChild['type'] = 'parent';
				$itemChild['children'] = $children;
			}
			else
			{
				$itemChild['type'] = 'child';
			}
			array_push($item, $itemChild);
		}

		return $item;
	}
?>