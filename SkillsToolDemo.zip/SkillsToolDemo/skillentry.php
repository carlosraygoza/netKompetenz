<head><title>Add an skill entry to the database</title>
</head>

<table border=0 width=100%  align=center><tr><td>

<?php


mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");
$query = "select lvlOfExpert, lvlOfIntr from employee_has_skill
		where skill_idskill='$idskill' AND employee_coreID='$coreID'";
$result = mysql_db_query("autoapps", $query);
$r = mysql_fetch_array($result);
if($r){

$lvlOfExpert = $r['lvlOfExpert'];
$lvlOfIntr = $r['lvlOfIntr'];



	if($r['lvlOfExpert']==0)
	  	$exp0='selected';
	if($r['lvlOfExpert']==1)
	  	$exp1='selected';
	if($r['lvlOfExpert']==2)
	  	$exp2='selected';
	if($r['lvlOfExpert']==3)
	  	$exp3='selected';


	if($r['lvlOfIntr']==0)
	    $intr0='selected';
	if($r['lvlOfIntr']==1)
	  	$intr1='selected';
	if($r['lvlOfIntr']==2)
	  	$intr2='selected';
	if($r['lvlOfIntr']==3)
	  	$intr3='selected';


	mysql_free_result($result);

}

$query = "select description, detailedDesc from skill
			where idskill='$idskill'";
$result = mysql_db_query("autoapps", $query);
$r = mysql_fetch_array($result);
$desc_skill = $r['description'];
$detailedDesc = $r['detailedDesc'];
if(!$detailedDesc)
  $detailedDesc = "no detailed description available";

mysql_free_result($result);


?>






<form method="post" action='index.php?site=changeSkill'>

<table  border=0 width=100% >
	<tr>
		<td width=100% style="height:275px;">
			<table class="tab_empty" width=100% height='100%' >



				<tr>
					<td colspan=2 valign=top>
						<h4>User: <?php echo $coreID; ?></h4>
						<h4>Skill: <?php echo $desc_skill; ?></h4>
						<h4>Detailed Descrition:</h4>
						<p><i>
						<?php print( $detailedDesc); ?>
						</i></p>
					</td>

				</tr>


				<tr>
					<td>
						<p>Level of Expertise:</p>
					</td>

					<td>
					<select name="lvlOfExpert" style="width: 150px;">
					<option <?php echo $exp0 ?> value="0">0 = No experience</option>
					<option <?php echo $exp1 ?> value="1">1 = Basic knowledge</option>
					<option <?php echo $exp2 ?> value="2">2 = Experienced</option>
					<option <?php echo $exp3 ?> value="3">3 = Guru</option>
					</select>
					</td>
				</tr>
				<tr>
					<td>
						<p>Level of Interest:</p>
					</td>

					<td>
						<select name="lvlOfIntr" style="width: 150px;">
						<option <?php echo $intr0 ?> value="0">0 = Leave me alone</option>
						<option <?php echo $intr1 ?> value="1">1 = Sounds cool</option>
						<option <?php echo $intr2 ?> value="2">2 = Interested</option>
						<option <?php echo $intr3 ?> value="3">3 = Can't get enough!</option>

					</td>
				</tr>
				<tr>
					<td></td>
					<td  width=50px>
						<input type="image" src="img/submit.gif" value="send">
						</form>
					</td>
				</tr>
			</table>
		</td>
		<td> <?php include 'googletest.php'; ?>
		</td>
		<td>
		<?php include 'skillStatistic.php';  ?>
		</td>
	</tr>
</table>

<p>
<?php 
$query = "SELECT skill_idskill1, skill_idskill, description FROM skill_has_skill INNER JOIN skill ON skill_has_skill.skill_idskill = skill.idskill WHERE skill_has_skill.skill_idskill1 =$idskill AND skill_has_skill.skill_idskill !=0";
$result = mysql_db_query("autoapps", $query);
echo "<b>skill parents</b>";
while($r = mysql_fetch_array($result)){
		echo ": <a href='index.php?site=skillentry&id=".$r['skill_idskill']."'>".$r['description']."</a> ";
}
?>
</p>
<input type="hidden" name="changeSkill" value="1">
<input type="hidden" name="nodeid" value=<? echo $idskill; ?>>

<?php include 'listOfSkillOwners.php'; ?>
</table>

