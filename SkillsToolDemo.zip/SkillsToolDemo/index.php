<?php
// start session if not already started
	session_start();
	error_reporting(0);

//**********START Define global variables for that page**********

	$table_title_color = 'rgb(255,165,00)';

//**********END Define global variables for that page************



//**********START get all POST and GET variables at once*********

	//actual site
	$getSite = $_GET['site'];
	$log_out = $_GET['log_out'];

	//get posted sites. TODO: add here any new site!
	$getExcelview = $_GET['excelview'];
	$getAdvanced = $_GET['advanced'];
	$getSkillsearch = $_GET['skillsearch'];
	$getGroupeditor = $_GET['groupeditor'];


	//skillid, it�s parents id and a descriptir
	$idskill=$_GET['id'];
	$pidskill=$_GET['pid'];
	$desc_skill = $_GET['desc_skill'];

	//To change the skill entries for one person we have to post the skill id and the new values
	$postChangeSkill = $_POST['changeSkill'];
	$postid =  $_POST['nodeid'];
	$postLvlOfExpert = $_POST['lvlOfExpert'];
	$postLvlOfIntr = $_POST['lvlOfIntr'];


	//TODO: not used! Will help if we implement admin rights
	$postAdmin = $_POST['admin'];

	//detailed description is posted due to it�s possible size
	$postDetailedDesc = $_POST['detailedDesc'];

	//those get�s are used to list other employees, locations or skills
	$getListOther = $_GET['listOther'];
	$getListOtherTeam = $_GET['listOtherTeam'];
	$getListOtherLoc = $_GET['listOtherLoc'];

//**********END get all POST and GET variables at once*********




//**********START check to see if user just logged out*********
	if ( $log_out )

	{
		//session_unregister( "valid_user" );

		session_destroy();

		session_start();

	}
//**********END check to see if user just logged out*************


//**********START print the log in text**************************
	function write_log_in( $text )

	{

			echo "
			<table class='SETD_MainHeader' width='100%'>
	            <tr style='height: 100px;'>
	                <td style='padding-left: 20px' class='SETD_MainHeaderLogo'>
	                    <img src='_Sources/Conti/Images/ContinentalLogo.png' alt='Continental HMI ID'>
	                </td>
	                <td class='SETD_MainHeaderCenterTitle'>
	                    <label>netKompetenz</label>
	                </td>
	                <td class='SETD_MainHeaderRightTitle'>
	                    <label>Log in</label>
	                </td>
	            </tr>
	        </table>
	        <table class='SETD_MainHeaderContentDivision'>
	            <tr><td/></tr>
	        </table>
	        <div id='body' style='overflow: auto'>
	            <?php echo $content; ?>
	        </div>
	        <br>
			<table style='padding-top: 30px;' align='center'>
			    <tr align='center' class='SETD_MainBodyPrimaryTitle'>
			        <td>
			            <label>User login information</label>
			        </td>
			    </tr>
			    <tr>
			        <td>
			            <form method='post' action='index.php' id='login-form'>
			            <div align='center' style='color: red;'>
			                <?php echo $form->errorSummary($model, '); ?>
			            </div>
			            <table class='SETD_GlobalEditionTable' align='center'>
			                <!-- UID -->
			                <tr>
			                    <td align='right'>
			                        <label id='UID_lbl'><b>UID:</b></label>
			                    </td>
			                    <td align='left'>
			                       	<input type=text name='coreID'>
			                    </td>
			                </tr>
			                <!--Password-->
			                <tr>
			                    <td align='right'>
			                        <label id='Pass_lbl'><b>Password:</b></label>
			                    </td>
			                    <td align='left'>
			                        <input type=password name='pwd'>
			                    </td> 
			                </tr>
			            </table>
			            <table align='center' >
			                <tr align='center'>
			                    <!--Enter button-->
			                    <td align='center'>
			                        <div align='center' id='menu_container'>
			                            <ul id='menu'> 
			                                <li>
			                                    <a href=\"javaScript: document.getElementById('login-form').submit();\">Submit</a>
			                                </li>
			                            </ul>
			                        </div>
			                    </td>
			                </tr>
			            </table>
			            <br>
			            <br>
			            </form>
			        </td>
			    </tr>
			</table>



		<!--

		<form method='post' action='index.php'>
		<table width=50% align=center>


		<tr><td>coreID:</td><td><input type=text name='coreID' size=40
		maxlength=100></td></tr>

		<tr><td>Password:</td><td><input type=password name='pwd' size=40
		maxlength=100></td></tr>

		<tr><td></td><td><input type=submit value=submit></td></tr>

		</form>
		</table>-->

			";

	}
//**********END print the log in text****************************


//**********START TODO: the funtion was thought to replace a long hidden/submit statement ******
	function hrefPost($text, $id, $action, $vars, $values){


		echo "<form name='form1' id='form1' method='post' action=''>
		  		<a href='javascript:document.form1.submit()'>Submit Form</a>
				</form>";

		echo "<form name='".$id."'  method='post' action='".$action."'>\n";

		$i=0;
		while($vars[$i] AND $values[$i]){
			echo "<input type='hidden' name='".$vars[$i]."' value='".$values[$i]."'>\n";
			$i++;
		}

		echo "<a href='#' onclick='this.menuGoogle.submit()'>".$text."</a>  ";

		echo "</form>\n";

	}
//**********END TODO: the funtion was thought to replace a long hidden/submit statement ******



//**********START prints a table header with the right tags for export**************************
	function writeTableTitleWithExport($title, $id, $select){

		echo "<br><b>$title </b><a href='".$_SERVER['REQUEST_URI']."&amp;export=$id' align='right'>export </a>";
		if($_GET['export']==$id)
			exportTableToCsv($id, $select);
	}
//**********END prints a table header with the right tags for export**************************

function exportTableToCsv($id, $query){


	mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");

	$result = mysql_db_query("autoapps", $query);
	$num_fields = mysql_num_fields($result);

	// Put the name of all fields to $out.
	for ($i = 0; $i < $num_fields; $i++) {
	$l=mysql_field_name($result, $i);
	$out .= '"'.$l.'",';
	}
	$out .="\n";

	// Add all values in the table to $out.
	while ($l = mysql_fetch_array($result)) {
		for ($i = 0; $i < $num_fields; $i++) {
			$out .='"'.$l["$i"].'",';
		}
		$out .="\n";
	}

	// Open file export.csv.
	$f = fopen ($id.'.csv','w');

	// Put all values from $out to export.csv.
	fputs($f, $out);
	fclose($f);

	echo "<a href='".$id.".csv"."' > | right click here to download .csv file</a>";


}




function writeTableHeader($id, $headers){
			echo "<br><table width=100%><tr><td><table  class='sortable' id='$id'  align=left border=1><tr>";
			$i = 0;
			global $table_title_color;
			while($headers[$i])
			{
				echo "<td align=center style='background-color: ".$table_title_color."'>".$headers[$i]."</td>
						";
				$i++;
			}
			echo "</tr>";


}

function writeTableHeaderWithTags($id, $headers, $tags){
			echo "<br><table width=100%><tr><td><table  class='sortable' id='$id'  align=left border=1><tr>";
			$i = 0;
			global $table_title_color;
			while($headers[$i])
			{
				echo "<td ".$tags[$i]." align=center style='background-color: ".$table_title_color."'>".$headers[$i]."</td>
						";
				$i++;
			}
			echo "</tr>";

}

function writeSelectTd($id,$options,$selected){
	$sTag ="	<select name='".$id."'>";

	$i=0;
	while($options[$i]){
		$sTag .= "<option ";
		if($selected==$i)
			$sTag .=" selected ";
		$sTag .= " value=".$i.">".$options[$i]."</option>";
		$i++;
	}
	$sTag .= "</select>
	";
	writeSimpleTd($sTag);

}

function writeSimpleTd($text){
	echo "<td>";
	echo $text;
	echo "</td>";
}

function writeColoredTd($text, $colorTag){
	echo "<td style='background-color:$colorTag'>";
	echo $text;
	echo "</td>";
}

function writeBarTd($pic, $val, $scale){
	echo "<td><nobr><img src='".$pic."' width='".($val * 80 / $scale)."' height='8'> ".round($val,2)."</nobr></td>";
}

function writeRefTd($text, $ref){
	echo "<td><a href='$ref'>$text</a></td>";
}

function writeTableEnd(){
		echo "</table></table>";
}

function verify()

{

	// check to see if they are already logged in

	if ( isset($_SESSION['valid_user'])) return true;

	// check to see if visitor has just tried to log on

	$coreID = $_POST["coreID"];

	$pwd = $_POST["pwd"];

	if ( $coreID && $pwd )

	{

		// verify password and log in to database

		mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");

		$select = "select coreID, Name from employee

		where coreID='$coreID'

		and passwd='$pwd'";

		$result = mysql_db_query("autoapps", $select);

		if ( mysql_num_rows( $result ) == 1 )
		{

			// register session variable and exit the verify function

			$valid_user = $coreID;

			$_SESSION['valid_user'] = $valid_user;
			$r = mysql_fetch_array($result);
			$_SESSION['Name'] = $r['Name'];

			return true;

		}

		else

		{

		// bad user and password

		$text = "User Name and Password did not match";

		write_log_in( $text );

		}

	}

	else

	{

	// user must log in

	//$text = "This is a secure server. Please log in.";

	write_log_in( $text );

	}

} // end verify function
?>

<!DOCTYPE html>

<html style="overflow:auto;">

<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="language" content="en"/>
	<link rel="stylesheet" type="text/css" href="_Sources/Conti/Styles/SETD_layout.css"/>
	<link rel="stylesheet" type="text/css" href="_Sources/bootstrap/css/bootstrap.min.css"/>
	<script src="_Sources/jquery/jquery.min.js"></script>
	<script src="_Sources/bootstrap/js/bootstrap.min.js"></script>
	<title>netKompetenz</title>

	<link rel="StyleSheet" href="dtree.css" type="text/css" />
	<script type="text/javascript" src="dtree.js"></script>
	<script type='text/javascript' src='sortable.js'></script>

</head>

<body class="SETD_MainBody">
                

<!--<table border=0 class='tab' width=100% >
	<tr>
		<td>
			<img src="img/fsl.gif" align=left>
		</td>

	</tr>
</table>


<div class='dtree'>
<table border=0 width=100%>
<tr>-->



<?php

$verified = verify();

if($_POST['setFilters']){

$_SESSION['teamFilter']= $_POST['teamFilter'];
$_SESSION['locationFilter'] = $_POST['locationFilter'];
}


?>



	<!--<td valign=top colspan=2>-->

		<?php

			if($verified )
			{
				if(!$getSite) $getSite = "home";

				include 'menu.php';

				echo "<tr><td width=300px valign=top>";
					include 'skillTree_v2.php';
				echo "</td><td valign=top>";

				$coreID=$_SESSION['valid_user'] ;

				if($postAdmin)
				{
					include 'admin.php';
				}

				if($getSite)
				{
					if($getSite==noSite)
					{
						if(($postChangeSkill OR $getChangeSkill OR $getListOther OR $getListOtherTeam OR $getListOtherLoc))
						{
								include 'changeSkill.php';
								$_SESSION['site']='';
						}
					}
					else
					{
						$_SESSION['site'] = $getSite;
						include $_SESSION['site'].'.php';
					}
				}
				else if($_SESSION['site'])
				{
					include $_SESSION['site'].'.php';
				}
				else
					include 'home.php';
			}
		?>


</td>
</tr>
</table>
</div>
