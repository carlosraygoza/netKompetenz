<?php
	//error_reporting(E_ALL ^ E_NOTICE);

//echo $_SESSION['post'];

//if($_SESSION['post']){
//	foreach($_SESSION['post'] AS $key=>$value){

//		echo $key."\n <br>";
//	}
//}

header("Content-type:text/xml"); print("<?xml version=\"1.0\"?>");
if (isset($_GET["id"]))
	$url_var=$_GET["id"];
else
	$url_var=0;
print("<tree id='".$url_var."'>");


if($lastPosOfUnderscore = strrpos($url_var, "_")){
	$trueId = substr($url_var, $lastPosOfUnderscore +1);
}
else{
	$trueId = $url_var;
}

//echo $trueId;

$oConn = mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");
mysql_select_db("autoapps",$oConn);
$result = mysql_query("SELECT * FROM skill_has_skill shs INNER JOIN skill s ON shs.skill_idskill1 = s.idskill  where skill_idskill=$trueId ORDER BY s.description");

echo $result;
print_r($result);


	while($arr=mysql_fetch_assoc($result))
	{

		$inta = $arr['description'];
		$intaid = $arr['skill_idskill1'];

		$inta = str_replace("'", " ", $inta);
		$inta = str_replace("&", "&amp;",$inta);

		$result2 = mysql_db_query("autoapps","SELECT * FROM skill_has_skill where skill_idskill=$intaid");

		if(mysql_num_rows($result2))
			$hasChildren=1;
		else
			$hasChildren=0;

		if($_GET[$url_var."_".$intaid])
			$isOpen = "open='true'";
		else
			$isOpen = "";

		if($_GET['site']=='groupeditor'){
			$menutag="site=groupeditor&amp;";
			if($_GET['addGroupSkill'])
				$menutag .= "addGroupSkill=1&amp;";
		}
		else if($_GET['site']=='treeeditor'){
			$menutag="site=treeeditor&amp;";
		}
		else if($_GET['site']=='changeSkill'){
					$menutag="site=changeSkill&amp;";
		}
		else
		$menutag="site=skillentry&amp;";

		$target = "index.php?".$menutag."id=".$intaid."&amp;pid=".$trueId;


		print("<item child='".$hasChildren."' id='".$url_var."_".$intaid."' text='".$inta."' ".$isOpen." >
							<userdata name='myurl'>".$target."</userdata>
							<userdata name='target'>".$intaid."</userdata></item>");
	}


	print("</tree>");
?>