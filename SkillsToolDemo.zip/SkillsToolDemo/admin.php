<table border=1 align=left>
<tr>
<td>

<form name="adminDel" action="index.php" method="post" >
<a name="delete" href="javascript:document.adminDel.submit();" >Delete  |</a>
</form>


<form name="adminMove" action="index.php" method="post" >
<a name="delete" href="javascript:document.adminMove.submit();" >Move  |</a>
</form>


<form name="adminCopy" action="index.php" method="post" >
<a name="delete" href="javascript:document.adminCopy.submit();" >Copy  |</a>
</form>



</td>
</tr>

</table>


<script type="text/javascript">
function submitForm(action){
	document.all.change_record.innerHTML = document.change_record + "<input type=hidden name=submit value='" + action +"'>";
	document.change_record.submit();
}
</script>