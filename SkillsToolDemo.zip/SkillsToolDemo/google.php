<?php
	error_reporting(0);
    //the response should be utf8 encoded
    header('Content-Type: text/html; charset=utf-8');

    //Include the basic API
    include_once("gvServerAPI.php");


    //------------------------------------------

    //-- Add here business logic, if needed
    //-- For example users authentication and access control

    //------------------------------------------

    //Initialize the gvStreamer objecy
    $gvJsonObj = new gvStreamer();
    $gvJsonObj->init();

    //Add columns
    $gvJsonObj->addColumn("0","Region","string");
    $gvJsonObj->addColumn("1","Expertise","number", "#0.#########");
    $gvJsonObj->addColumn("2","Interest","number", "#0.#########");



    //echo $gvJsonObj;



$countriesExpert = array();
$countriesIntr = array();

mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");

$select = "SELECT countryCode FROM location";

$result = mysql_db_query("autoapps", $select);

while($r = mysql_fetch_array($result)){
	$countriesExpert[$r['countryCode']] = 0;
	$countriesIntr[$r['countryCode']] = 0;
}



foreach($countries AS $key=>$value  ){
	echo $key."<br>";
	echo $value."<br>";
	$out .=$key.", ".$value."<br>";
}

//echo $idskill;

addNode($_GET['id']);

function addNode($skillid){
	global $countriesExpert;
	global $countriesIntr;

	$select = "SELECT
				SUM(lvlOfExpert) AS sumExpert,
				SUM(lvlOfIntr) AS sumIntr,
				countryCode
				FROM employee_has_skill
				INNER JOIN employee
				ON employee.coreID=employee_has_skill.employee_coreID
				INNER JOIN location
				on employee.location_id = location.id
				WHERE employee_has_skill.skill_idskill=$skillid
				GROUP BY countryCode";



	$result = mysql_db_query("autoapps", $select);

	while($r = mysql_fetch_array($result)){
		$countriesExpert[$r['countryCode']] += $r['sumExpert'];
		$countriesIntr[$r['countryCode']] += $r['sumIntr'];
	}

/*
	$select = "SELECT * FROM skill_has_skill WHERE
			 skill_has_skill.skill_idskill=$skillid";



	$result = mysql_db_query("autoapps", $select);

	while($r = mysql_fetch_array($result)){
		addNode($r['skill_idskill1']);
	}
*/

}

$out = '';

foreach($countriesExpert AS $key=>$value  ){


	  $gvJsonObj->addNewRow();
	  $gvJsonObj->addStringCellToRow($key);
	  $gvJsonObj->addNumberCellToRow($value, "$value");
	  $gvJsonObj->addNumberCellToRow($countriesIntr[$key], "$countriesIntr[$key]");



}

//echo $out;
echo $gvJsonObj;

?>

