<?php
	include "logManager.php";
	
	$oConn = mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");
	mysql_select_db("autoapps",$oConn);


	// Get Action from _POST
	$action = null;
	$parent = null;
	$node = null;
	$nodeName = null;
	$newName = null;
	$relationID = null;

	if(isset($_POST['action'])) $action = $_POST['action'];
	if(isset($_POST['parent'])) $parent = $_POST['parent'];
	if(isset($_POST['node'])) $node = $_POST['node'];
	if(isset($_POST['nodeName'])) $nodeName = $_POST['nodeName'];
	if(isset($_POST['newName'])) $newName = $_POST['newName'];
	if(isset($_POST['relationID'])) $relationID = $_POST['relationID'];

	$result = array();

	switch ($action) 
	{
		case 'create':
			if($nodeName != null && $parent != null)
				$result['success'] = createNode($nodeName, $parent);
			break;

		case 'rename':
			if($node != null && $newName != null)
				$result['success'] = renameNode($node, $newName);
			break;

		case 'delete':
			if($node != null)
				$result['success'] = deleteNode($node);
			break;

		case 'copy':
			if($node != null && $parent != null)
				$result['success'] = copyNode($node, $parent);
			break;

		case 'move':
			if($node != null && $parent != null && $relationID != null)
				$result['success'] = moveNode($node, $parent, $relationID);
			break;

		default:
			break;
	}

	echo json_encode($result);

	function createNode($nodeName, $parent)
	{
		$insertSkillQuery = "INSERT INTO skill (description) VALUES ('$nodeName')";
		$result =  mysql_query($insertSkillQuery);
		if($result)
		{
			$newSkillID = mysql_insert_id();

			// insert log
			$info = array();
			$column['idskill']['newValue'] = $newSkillID;
			$column['description']['newValue'] = $nodeName;
			array_push($info, $column);
			insertLog("insert","skill", $info);


			if(addNewParent($newSkillID, $parent))
			{
				$array['skillid'] = $newSkillID;
				$array['treeid'] = mysql_insert_id();
				return $array;
			}
		}
		return false;
	}

	function renameNode($node, $newName)
	{
		$getOld = "SELECT description FROM skill WHERE idskill='$node'";
		$result = mysql_query($getOld);

		while($old = mysql_fetch_assoc($result))
		{
			$oldDescription = $old['description'];
		}

		$updateSkillQuery = "UPDATE skill SET description='$newName' WHERE idskill='$node'";
		if(mysql_query($updateSkillQuery))
		{
			// insert log
			$info = array();
			$column['description']['oldValue'] = $oldDescription;
			$column['description']['newValue'] = $newName;
			$column['WHERE']['idskill'] = $node;
			array_push($info, $column);
			insertLog("update","skill", $info);

			return true;
		}
		return false;
	}

	function deleteNode($node)
	{
		if(deleteOldParents($node))
		{
			/*$deleteSkillQuery = "DELETE FROM skill WHERE idskill = $node";
			if(mysql_query($deleteSkillQuery))
			{
				// insert log
				$info = array();
				$column['WHERE']['idskill'] = $node;
				array_push($info, $column);
				insertLog("delete","skill", $info);

				return true;
			}*/

			return true;
		}
		return false;
	}

	function copyNode($node, $parent)
	{
		if(addNewParent($node, $parent))
		{
			return mysql_insert_id();
		}
		return false;		
	}

	function moveNode($node, $parent, $relationID)
	{
		if(deleteOldParents($relationID))
		{
			if(addNewParent($node, $parent))
			{
				return mysql_insert_id();
			}
		}
		return false;
	}



	function deleteOldParents($node)
	{
		$getOldValues = "SELECT * FROM skill_has_skill WHERE idshs = $node";
		$result = mysql_query($getOldValues);
		while($oldValues = mysql_fetch_assoc($result))
		{
			$parent = $oldValues['skill_idskill'];
			$child = $oldValues['skill_idskill1'];
		}


		$deleteSkillParentQuery = "DELETE FROM skill_has_skill WHERE idshs = $node";
		if(mysql_query($deleteSkillParentQuery))
		{
			// insert log
			$info = array();
			$column['WHERE']['skill_idskill'] = $parent;
			$column['WHERE']['skill_idskill1'] = $child;
			array_push($info, $column);
			insertLog("delete","skill_has_skill", $info);

			return true;
		}

		return false;
	}

	function addNewParent($node, $parent)
	{
		$insertRelation = "INSERT INTO skill_has_skill (skill_idskill, skill_idskill1) VALUES ('$parent', '$node')";

		// insert log
		$info = array();
		$column['skill_idskill']['newValue'] = $parent;
		$column['skill_idskill1']['newValue'] = $node;
		array_push($info, $column);
		insertLog("insert","skill_has_skill", $info);				

		return mysql_query($insertRelation);
	}
?>