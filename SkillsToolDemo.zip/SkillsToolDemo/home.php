

<table width=100%>
	<tr>
		<td valign=top><p style="text-align: justify;">
			<br>
			<h3>Hello!</h3>
			Good to know you made it here. Find here soon a nice description of how that tool works.

			<h4>Disclaimer</h4>
			I intentionally added no special "admin" rights to that system. So please enjoy your responsibility and maintain that system clean, useful and always up to date!
			<br><br>
			Thanks!!
			</p>
		</td>
		<td>
			<img src="img/skillsCrossword.jpg" >
		</td>
	</tr>
</table>
