<?php
function getTeamFilterOptions(){
	mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");

	$select = "SELECT * from team";
	$result = mysql_db_query("autoapps", $select);

	echo "<select name='teamFilter' onChange='this.form.submit();'> ";
	echo "<option value=''>No filter</option>";
	while($r=mysql_fetch_array($result)){
		if($_SESSION['teamFilter']==$r['id'])
			$selected = "selected";
		else
			$selected = "";
		echo "<option $selected value=".$r['id'].">".$r['name']."</option> \n";
	}
	echo "</select>";
}

function getLocationFilterOptions(){
	mysql_connect("127.0.0.1","skillsUser","skillsAdmin.") or die ("Problem connecting to DataBase");

	$select = "SELECT * from location";
	$result = mysql_db_query("autoapps", $select);

	echo "<select name='locationFilter'  onChange='this.form.submit();'> ";
	echo "<option value=''>No filter</option>";
	while($r=mysql_fetch_array($result)){
		if($_SESSION['locationFilter']==$r['id'])
					$selected = "selected";
				else
					$selected = "";
		echo "<option $selected value=".$r['id'].">".$r['name']."</option> \n";
	}
	echo "</select>";

}

?>
<div id="header">
    <table class="SETD_MainHeader" width="100%">
        <tr style="height: 100px;">
            <td class="SETD_MainHeaderLogo">
                <div class="branding">
                    <a class="brand-logo" href=""></a>
                    <!--<a class="brand-logo" href="/site"></a>-->
                </div>
            </td>
            <td class="SETD_MainHeaderCenterTitle">
                <label>netKompetenz</label>
            </td>
			<td class="SETD_MainHeaderRightTitle">
                    <div class="nav-box-top">
                        <div>
                            <label class="nav-box-username">Welcolme <?php echo $_SESSION['Name'];?></label>
                        </div>
                        <div class="nav-box-wrapper">
                            <div class="nav-box-logout">
                            	<a class="nav-box-logout-link" href="index.php?log_out=1">
                            		<i class="fa fa-sign-out fa-fw">Log Out</i>
                        		</a>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
            <tr>
                <td colspan="3" align="center">
                    <table class="SETD_MainHeaderMenu">
                        <tr>
                            <td>
                                <ul id="yw0">
                                	<?php if($getSite == "home"): ?> 
                                		<li class="SETD_MainHeaderMenuSelected SETD_MainHeaderMenuNotSelected">
                            		<?php else: ?> 
                            			<li class="SETD_MainHeaderMenuNotSelected">
                            		<?php endif; ?>
                                		<a href='index.php?site=home'>Home</a>
                                	</li>

                                	<?php if($getSite == "groupeditor"): ?> 
                                		<li class="SETD_MainHeaderMenuSelected SETD_MainHeaderMenuNotSelected">
                            		<?php else: ?> 
                            			<li class="SETD_MainHeaderMenuNotSelected">
                            		<?php endif; ?>
                                		<a href='index.php?site=groupeditor'>Group Editor</a>
                                	</li>

                                	<?php if($getSite == "treeeditor"): ?> 
                                		<li class="SETD_MainHeaderMenuSelected SETD_MainHeaderMenuNotSelected">
                            		<?php else: ?> 
                            			<li class="SETD_MainHeaderMenuNotSelected">
                            		<?php endif; ?>
                                		<a href='index.php?site=treeeditor'>Tree Editor</a>
                                	</li>

                                	<?php if($getSite == "skillsearch"): ?> 
                                		<li class="SETD_MainHeaderMenuSelected SETD_MainHeaderMenuNotSelected">
                            		<?php else: ?> 
                            			<li class="SETD_MainHeaderMenuNotSelected">
                            		<?php endif; ?>
                                		<a href='index.php?site=skillsearch'>Search Skill</a>
                                	</li>
                                	<!--<li class="SETD_MainHeaderMenuNotSelected">
                                		<a href='index.php?site=excelview'>excel view</a>
                                	</li>
                                	<li class="SETD_MainHeaderMenuNotSelected">
                                		<a href='index.php?site=advanced'>advanced</a>
                                	</li>
                                	<li class="SETD_MainHeaderMenuNotSelected">
                                		<a href='index.php?site=listteams'>list teams</a>
                                	</li>-->
                                </ul>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <table class="SETD_MainHeaderContentDivision">
            <tr><td/></tr>
        </table>
		<table align="right">
			<form method="post" action=<?echo $_SERVER['REQUEST_URI']; ?>>
            <tr>
			<td colspan=9 align=right style="padding-right:43px"><b>Filters:</b>

				<input type='hidden' id='setFilters' name='setFilters' value='1'>
				<?php getTeamFilterOptions(); ?>

				<?php getLocationFilterOptions(); ?>
			</td>
			</tr>
            </form>
		</table>
</div>
<table height="300px">


<!--<table class="menu" width=100%>
	<tr>
		<td style='background-color: rgb(215, 234, 238);'><nobr><b><?echo $_SESSION['Name']?></b></nobr>
		</td>
		<td style='background-color: rgb(215, 234, 238);' align=center><nobr><a href='index.php?site=home'>home</a></nobr>
		</td>
		<td style='background-color: rgb(215, 234, 238);' align=center><nobr><a href='index.php?site=groupeditor'>group editor</a></nobr>
		</td>
		<td style='background-color: rgb(215, 234, 238);' align=center><nobr><a href='index.php?site=treeeditor'>tree editor</a></nobr>
		</td>
		<td style='background-color: rgb(215, 234, 238);' align=center><nobr><a href='index.php?site=skillsearch'>search skill</a></nobr>
		</td>
		<td style='background-color: rgb(215, 234, 238);' align=center><nobr><a href='index.php?site=excelview'>excel view</a></nobr>
		</td>
		<td style='background-color: rgb(215, 234, 238);' align=center><nobr><a href='index.php?site=advanced'>advanced</a></nobr>
		</td>
		<td style='background-color: rgb(215, 234, 238);' align=center><nobr><a href='index.php?site=listteams'>list teams</a></nobr>
		</td>
		<td style='background-color: rgb(215, 234, 238);' align=center><nobr><a href='index.php?log_out=1'>log out</a></nobr>
		</td>
	</tr>
	<tr><form method="post" action=<?echo $_SERVER['REQUEST_URI'] ?>>
		<td colspan=9 align=right><b>Filters:</b>

			<input type='hidden' id='setFilters' name='setFilters' value='1'>
			<?php getTeamFilterOptions(); ?>

			<?php getLocationFilterOptions(); ?>
		</td>
	</tr></form>
</table>-->




