/***************************************************************************
*=====================      Copyright by Continental AG      ===============
****************************************************************************
* Title        : Autoresize.js
*
* Description  : Script used to auto resize the heigh of the content of a web window      
*
* Environment  : Web Development
*
* Responsible  : Roberto Lopez
*
* Rev 1.0:  01 Aug 2016
* Author:   Roberto Lopez
*	- Initial Release.
*	
* Rev 1.1:  14 Mar 2017
* Author:   Roberto Lopez
*	- Added phpGrid resize.
*
* End of Revision History
****************************************************************************/ 


$(document).ready(function()
{
    // Resize body heigh
    var header_height = $('#header').height();
    $("#body").height($(window).height()-header_height);
    $(window).resize(function()
    {
        var header_height_resize = $('#header').height();
        $("#body").height($(window).height()-header_height_resize);
    });
    
    // Resize phpgrid objects
    if($(".gridContainer").length > 0)
    {
        $(".gridContainer").each(function(index){
            $(this).height($("#body").height()-150);
            var ContainerWidth = $(this).width();
            var ContainerHeight = $(this).height();
            $(this).find('.ui-jqgrid-btable').each(function(index){
                var GridID = $(this).attr("id");
                $("#"+GridID).jqGrid('setGridHeight',ContainerHeight-50);
                $("#"+GridID).jqGrid('setGridWidth',ContainerWidth);
            });
        });            
    }
    
    $(window).resize(function(){
        if($(".gridContainer").length > 0)
        {
            $(".gridContainer").each(function(index){
                $(this).height($("#body").height()-150);
                var ContainerWidth = $(this).width();
                var ContainerHeight = $(this).height();
                $(this).find('.ui-jqgrid-btable').each(function(index){
                    var GridID = $(this).attr("id");
                    $("#"+GridID).jqGrid('setGridHeight',ContainerHeight-50);
                    $("#"+GridID).jqGrid('setGridWidth',ContainerWidth);
                });
            });            
        }
    });
});