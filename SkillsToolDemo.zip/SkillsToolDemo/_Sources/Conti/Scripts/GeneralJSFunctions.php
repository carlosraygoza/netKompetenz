/***************************************************************************
*=====================      Copyright by Continental AG      ===============
****************************************************************************
* Title        : GeneralJSFunctions.php
*
* Description  : Script that stores AJAX functions, validatation fields functions, 
*               submit forms functions and global JS scripts     
*
* Environment  : Web Development
*
* Responsible  : Roberto Lopez
*
* Rev 1.0:  02 Aug 2016
* Author:   Roberto Lopez
*   - Initial Release.
*
* End of Revision History
****************************************************************************/

<?php
    header("Content-type: application/javascript");
    include_once '../../../Config/FTT_Cfg_Defines.php';
?>

// Color definition
var sInvalidColor = '#FF0000';
var sValidColor = '#484848';


/************************************** LOGIN FORM ***************************************/

/**
 * Submit login form
 */
function AJAX_login()
{
    if(ValidateLogin())
    {
        $.ajax({
            url:"<?php echo URL; ?>index/login",
            type:"POST",
            data: new FormData(login_form),
            contentType: false,
            cache:false,
            processData:false,
            success:function(data)
            {
                var oResult = jQuery.parseJSON( data );
                if(oResult.Logged)
                {
                    window.location.href = oResult.GoTo;
                }
                else
                {
                    alert("The uid or password you entered is incorrect or you don't have Admin privileges");
                }
            }
        });
    }
}

/**
 * Validate login fields
 */
function ValidateLogin()
{
    //Value to return
    var boValidFields = true;
    //String containing empty fields
    var sEmptyFieldsAlert = "";
    
    //Validate UID field
    if($("#User_UID_tbox").val().length != 8)
    {
        boValidFields = false;
        sEmptyFieldsAlert = sEmptyFieldsAlert + "\n* UID - Must be 8 characters";
        //Set label color red
        document.getElementById("UID_lbl").style.color = sInvalidColor;
    }
    else if(!($("#User_UID_tbox").val().toLowerCase().match("^uid")))
    {
        boValidFields = false;
        sEmptyFieldsAlert = sEmptyFieldsAlert + "\n* UID - Must start with 'uid'";
        //Set label color red
        document.getElementById("UID_lbl").style.color = sInvalidColor;
    }
    else
    {
        //Hide label color normal
        document.getElementById("UID_lbl").style.color = sValidColor;
    }

    //Validate Password field
    if($("#User_Pass_tbox").val() == "")
    {
        boValidFields = false;
        sEmptyFieldsAlert = sEmptyFieldsAlert + "\n* Password - Enter your password";
        //Set label color red
        document.getElementById("Pass_lbl").style.color = sInvalidColor;
    }
    else
    {
        //Hide label color normal
        document.getElementById("Pass_lbl").style.color = sValidColor;
    }
    
    //Show error alert based on empty fields
    if(!boValidFields)
    {
        alert("Complete the following field(s) before submit:\n" + sEmptyFieldsAlert);
    }
    return boValidFields;
}

/************************************** CHANGE PASSWORD FORM ***************************************/

/**
 * Submit change password form
 */
function AJAX_changePassword()
{
    if(ValidateChangePassword())
    {
        $.ajax({
            url:"<?php echo URL; ?>index/changepassword",
            type:"POST",
            data: new FormData(ChangePassword_form),
            contentType: false,
            cache:false,
            processData:false,
            success:function(data)
            {
                var oResult = jQuery.parseJSON( data );
                if(oResult.Success)
                {
                    alert("Your password was successfully updated, please restart the session to apply the changes");
                    window.location.href = "<?php echo URL; ?>index/changepassword";
                }
                else if(!oResult.ValidUID)
                {
                    alert("The entered UID is not register in DB");
                    document.getElementById("UID_lbl").style.color = sInvalidColor;
                }
                else if(!oResult.CorrectPass)
                {
                    alert("Incorrect password!");
                    document.getElementById("CurrPass_lbl").style.color = sInvalidColor;
                }
            }
        });
    }
}

/**
 * Validate login fields
 */
function ValidateChangePassword()
{
    //Value to return
    var boValidFields = true;
    //String containing empty fields
    var sEmptyFieldsAlert = "";
    
    //Validate UID field
    if($("#User_UID_tbox").val().length != 8)
    {
        boValidFields = false;
        sEmptyFieldsAlert = sEmptyFieldsAlert + "\n* UID - Must be 8 characters";
        //Set label color red
        document.getElementById("UID_lbl").style.color = sInvalidColor;
    }
    else if(!($("#User_UID_tbox").val().toLowerCase().match("^uid")))
    {
        boValidFields = false;
        sEmptyFieldsAlert = sEmptyFieldsAlert + "\n* UID - Must start with 'uid'";
        //Set label color red
        document.getElementById("UID_lbl").style.color = sInvalidColor;
    }
    else
    {
        //Hide label color normal
        document.getElementById("UID_lbl").style.color = sValidColor;
    }

    //Validate Current Password field
    if($("#CurrPass_tbox").val() == "")
    {
        boValidFields = false;
        sEmptyFieldsAlert = sEmptyFieldsAlert + "\n* Current Password - Enter your password";
        //Set label color red
        document.getElementById("CurrPass_lbl").style.color = sInvalidColor;
    }
    else
    {
        //Hide label color normal
        document.getElementById("CurrPass_lbl").style.color = sValidColor;
    }
    
    //Validate New Password field
    if($("#NewPass_tbox").val() == "")
    {
        boValidFields = false;
        sEmptyFieldsAlert = sEmptyFieldsAlert + "\n* New Password - Enter your password";
        //Set label color red
        document.getElementById("NewPass_lbl").style.color = sInvalidColor;
    }
    else
    {
        //Hide label color normal
        document.getElementById("NewPass_lbl").style.color = sValidColor;
    }
    
    //Validate Repeat Password field
    if($("#RepPass_tbox").val() == "")
    {
        boValidFields = false;
        sEmptyFieldsAlert = sEmptyFieldsAlert + "\n* Repeat New Password - Enter your password";
        //Set label color red
        document.getElementById("RepPass_lbl").style.color = sInvalidColor;
    }
    else if($("#RepPass_tbox").val() != $("#NewPass_tbox").val())
    {
        boValidFields = false;
        sEmptyFieldsAlert = sEmptyFieldsAlert + "\n* Repeat New Password - Passwords doesn't match";
        //Set label color red
        document.getElementById("RepPass_lbl").style.color = sInvalidColor;
    }
    else
    {
        //Hide label color normal
        document.getElementById("RepPass_lbl").style.color = sValidColor;
    }
    
    //Show error alert based on empty fields
    if(!boValidFields)
    {
        alert("Complete the following field(s) before submit:\n" + sEmptyFieldsAlert);
    }
    return boValidFields;
}


/************************************** RESTORE PASSWORD FORM ***************************************/

/**
 * Submit restore password form
 */
function AJAX_restorePassword()
{
    if(ValidateRestorePassword())
    {
        $.ajax({
            url:"<?php echo URL; ?>index/restorepassword",
            type:"POST",
            data: new FormData(RestorePassword_form),
            contentType: false,
            cache:false,
            processData:false,
            success:function(data)
            {
                var oResult = jQuery.parseJSON( data );
                if(oResult.Success)
                {
                    alert("Your password was successfully restored, an email with the new password was sent to : "+oResult.UserEmail);
                    window.location.href = "<?php echo URL; ?>index/restorepassword";
                }
                else if(!oResult.ValidUID)
                {
                    alert("The entered UID is not register in DB");
                }
                else if(!oResult.EmailSent)
                {
                    alert("There is a problen sending the email, please contact Tools group");
                }
            }
        });
    }
}

/**
 * Validate login fields
 */
function ValidateRestorePassword()
{
    //Value to return
    var boValidFields = true;
    //String containing empty fields
    var sEmptyFieldsAlert = "";
    
    //Validate UID field
    if($("#User_UID_tbox").val().length != 8)
    {
        boValidFields = false;
        sEmptyFieldsAlert = sEmptyFieldsAlert + "\n* UID - Must be 8 characters";
    }
    else if(!($("#User_UID_tbox").val().toLowerCase().match("^uid")))
    {
        boValidFields = false;
        sEmptyFieldsAlert = sEmptyFieldsAlert + "\n* UID - Must start with 'uid'";
    }
    
    //Show error alert based on empty fields
    if(!boValidFields)
    {
        alert("Complete the following field(s) before submit:\n" + sEmptyFieldsAlert);
    }
    return boValidFields;
}
