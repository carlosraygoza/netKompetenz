/***************************************************************************
*=====================      Copyright by Continental AG      ===============
****************************************************************************
* Title        : SubmitEnter.js
*
* Description  : Script used to submit the form of the field when <ENTER> is typed      
*
* Environment  : Web Development
*
* Responsible  : Roberto Lopez
*
* Rev 1.0:  02 Aug 2016
* Author:   Roberto Lopez
*	- Initial Release.
*
* End of Revision History
****************************************************************************/

/**
 * Function that calls the submit function when the enter is typed
 * @param {input} myfield
 * @param {Event} e
 * @param {String} submitFunction
 * @returns {Boolean}
 */
function bSubmitEnter(myfield,e,submitFunction) 
{ 
    var keycode; 
    if (window.event) keycode = window.event.keyCode; 

    else if (e) keycode = e.which; 
        else return true;
    if (keycode == 13) 
    { 
        window[submitFunction]("");
        return false; 
    } 
    else 
        return true; 
} 