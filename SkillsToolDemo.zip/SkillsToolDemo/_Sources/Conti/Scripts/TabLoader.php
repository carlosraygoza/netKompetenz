/***************************************************************************
*=====================      Copyright by Continental AG      ===============
****************************************************************************
* Title        : TabLoader.php
*
* Description  : Script used to show the tabs according the user type.    
*
* Environment  : Web Development
*
* Responsible  : Roberto Lopez
*
* Rev 1.0:  02 Aug 2016
* Author:   Roberto Lopez
*   - Initial Release.
*
* End of Revision History
****************************************************************************/

<?php
    header("Content-type: application/javascript");
    
    error_reporting(0);
    session_start();
    // Include tab definition file
    include_once '../../../Config/FTT_Cfg_TabDefinition.php';
    // Include User Class file
    include_once '../../../Models/SessionUser.php';
    // Get user roles
    use Models\SessionUser as User;
    $oUser = new User();
    $iUserType = $oUser->getIUser_Type();
?>

/**
 * Function used to append the correct tabs according the user role
 */
function LoadTabs()
{
    <?php
        // Foreach tab definition in "Cfg_TabDefinition" file
        foreach ($aTabsDefinition as $oTab)
        {
            //Initialize the add flag to false
            $bAdd = false;
            // If the user type is in the accepted types array of the tab
            if (in_array($iUserType, $oTab['types']))
            {
                // Set the flag to true
                $bAdd = true;
            }
            // If flag is true
            if($bAdd)
            {
                // Append the tab to the td with id "tdTab_Space"
                ?>
                    var sUL = "<ul id=\"<?php echo $oTab['id']; ?>\" class=\"SETD_MainHeaderMenuNotSelected\"><li><a href=\"<?php echo $oTab['href'] ?>\"><?php echo $oTab['name'] ?></a></li></ul>";
                    $("#tdTab_Space").append(sUL);
                <?php
                // Set the flag to false
                $bAdd = false;
            }
        }
    ?>
}

/**
 * Function used to set selected the tab in the general template of a view
 */
function SetSelectedTab(sTabID)
{
    $("#"+sTabID).addClass('SETD_MainHeaderMenuSelected').removeClass('SETD_MainHeaderMenuNotSelected');
}